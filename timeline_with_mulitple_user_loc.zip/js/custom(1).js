let map, marker = null;
let animationInterval = null;
const polylineRefs = [];
const markerRefs = [];
const colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown', 'teal', 'darkblue', 'maroon'];
function initMap() {
    map = L.map('map').setView([21.218, 74.833], 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
}

function clearMap() {
    polylineRefs.forEach(line => map.removeLayer(line));
    markerRefs.forEach(m => map.removeLayer(m));
    polylineRefs.length = 0;
    markerRefs.length = 0;
    if (animationInterval) clearInterval(animationInterval);
    if (marker) {
        map.removeLayer(marker);
        marker = null;
    }
}

function drawPolyline(coords, color = 'blue') {
    const polyline = L.polyline(coords, { color }).addTo(map);
    polylineRefs.push(polyline);
    return polyline;
}

function createColoredMarker(position, color = 'blue') {
    const icon = L.icon({
        iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
        shadowSize: [41, 41]
    });
    const m = L.marker(position, { icon }).addTo(map);
    markerRefs.push(m);
    return m;
}

function startLiveTracking(points, color = 'blue') {
    if (!points || points.length === 0) return;

    let index = 0;

    // Create colored icon
    const icon = L.icon({
        iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
        shadowSize: [41, 41]
    });

    if (marker) map.removeLayer(marker);
    marker = L.marker(points[0], { icon }).addTo(map);

    animationInterval = setInterval(() => {
        index++;
        if (index >= points.length) {
            clearInterval(animationInterval);
            return;
        }
        marker.setLatLng(points[index]);
    }, 10000);
}

    

function stopUserTracking() {
    if (userPollingInterval) {
        clearInterval(userPollingInterval);
        userPollingInterval = null;
        console.log("🛑 User live tracking stopped.");
    }
}

function displayMultipleEntries(entries) {
    clearMap();
    if (!entries || entries.length === 0) return;

    let liveTracked = false;
    const timelineContainer = document.querySelector('.timeline-detail');
    timelineContainer.innerHTML = ''; // Clear timeline

    entries.forEach((entry, idx) => {
        const coords = entry.locations.map(p => [p.lat, p.lng]);
        const color = colors[idx % colors.length];

        const poly = drawPolyline(coords, color);
        const lastCoord = coords[coords.length - 1];

        // 🟢 Live tracking (only once, for first entry with stage == 1)
        if (entry.stage == 1 && !liveTracked) {
            map.fitBounds(poly.getBounds());
            liveTracked = true;

            // Animate live marker
            startLiveTracking(coords, color); // Pass color for marker
        } else {
            // Static marker only
            createColoredMarker(lastCoord, color);
        }

        // Timeline Section
        // <div class="stop-marker">📍</div>
        timelineContainer.innerHTML += `<h4 style="color:${color};">Entry ${idx + 1}</h4>`;
        if (entry.stops && entry.stops.length > 0) {
            entry.stops.forEach((stop, sIndex) => {
                // timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">🚗</div>
                        
                //         <strong>Stop ${sIndex + 1}</strong><br>
                //         From: ${stop.from}<br>
                //         To: ${stop.to}<br>
                //         <span>Duration: ${stop.duration_min} mins</span><br>
                        
                //     </div>`;
                timelineContainer.innerHTML += `
                     <div 
                            class="stop-entry" 
                            style="cursor:pointer;"
                            data-lat="${parseFloat(stop.lat)}" 
                            data-lng="${parseFloat(stop.lng)}"
                        >
                        <div class="stop-marker">🚗</div>

                        
                        
                        <strong>Stop ${sIndex + 1}</strong><br>
                        From: ${stop.from}<br>
                        To: ${stop.to}<br>
                        <span>Duration: ${stop.duration_min} mins</span><br>
                        
                    </div>`;
            });
            // Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
            
            document.querySelectorAll('.stop-entry').forEach(entry => {
                console.log('stop entry===', entry)
                entry.addEventListener('click', function () {
                    const lat = parseFloat(this.getAttribute('data-lat'));
                    const lng = parseFloat(this.getAttribute('data-lng'));
            
                    // Remove old marker if needed
                    if (marker) map.removeLayer(marker);
            
                    // Add new marker for clicked stop
                    marker = L.marker([lat, lng]).addTo(map).bindPopup("Selected Stop").openPopup();
                    map.setView([lat, lng], 17);
                });
            });
        } else {
            timelineContainer.innerHTML += `<div>No significant stops (5+ min)</div>`;
        }
    });
}


// 👇 Example call
function fetchUserData(userId, selectedDate) {
    fetch(`/location/timeline/api/data.php?user_id=${userId}&date=${selectedDate}`)
        .then(res => res.json())
        .then(data => {
            if (data.entries && data.entries.length > 0) {
                displayMultipleEntries(data.entries);
            } else {
                clearMap();
                alert("No tracking data found.");
            }
        })
        .catch(err => {
            console.error("Error loading tracking data:", err);
            clearMap();
        });
}



    


function updateLocation() {
        const urlParams = new URLSearchParams(window.location.search);
        let recordId = '';
        let url = '';

        if (urlParams.get('visitor_id')) {
            recordId = urlParams.get('visitor_id');
            url = '/location/timeline/api/get_visitor_data.php';
        } else {
            recordId = urlParams.get('user_id');
            url = '/location/timeline/api/get_all_emp_data.php';
        }

        $.ajax({
            url: url,
            method: 'POST',
            data: { id: recordId },
            dataType: 'json',
            success: function (response) {
                console.log("Received JSON:", response);
                $('#user_id').html(response.data);
                const dropdown = document.getElementById('user_id');
                const userId =  response.userid;//urlParams.get('user_id');
                if (dropdown) {
                        // dropdown.val([userId]).trigger('change');
                    const optionToSelect = dropdown.querySelector(`option[value="${userId}"]`);
                    if (optionToSelect) {
                        optionToSelect.selected = true;
                    }
                }
                $('.id_set h2').text(response.username);
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
            }
        });
    }

function toggleCalendar() {
const inputDiv = document.getElementById("calendarInput");
inputDiv.style.display = inputDiv.style.display === "block" ? "none" : "block";
$('.calendar-icon').css('display', 'none');
}

function updateDate() {
        const dateValue = document.getElementById("datePicker").value;
        if (dateValue) {
            const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
            const formatted = new Date(dateValue).toLocaleDateString('en-GB', options);
            document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');

            // 🔁 Refetch data for all selected users
            const urlParams = new URLSearchParams(window.location.search);
            const visitorId = urlParams.get('visitor_id');
            const userId = urlParams.get('user_id');
            console.log('visitorId', visitorId, 'userId', userId)

            if (visitorId) {
                fetchVisitorData(visitorId, dateValue); // ✅ Load only if visitor_id is present
            }else{
                const selected = $('#user_id').val();
                if(selected == null){
                    console.log('userId ', userId);
                    console.log('dateValue ', dateValue);
                    fetchUserData(userId, dateValue)
                }else{
                    console.log('userrrrr ', selected);
                    console.log('dateValue ', dateValue);
                    fetchUserData(selected, dateValue)
                }
                
            }
        }
    }
    
let visitorPollingInterval = null;    

function stopVisitorTracking() {
    if (visitorPollingInterval) {
        clearInterval(visitorPollingInterval);
        visitorPollingInterval = null;
        console.log("🔁 Live tracking stopped.");
    }
}
    
function drawVisitorRoute(coords, color = 'blue') {
    polyline = L.polyline(coords, { color }).addTo(map);
    map.fitBounds(polyline.getBounds());
}


function fetchVisitorData(visitorId, selectedDate) {
    fetch(`/location/timeline/api/data.php?visitor_id=${visitorId}&date=${selectedDate}`)
        .then(res => res.json())
            .then(data => {
                if (data.entries && data.entries.length > 0) {
                    displayMultipleEntries(data.entries);
                } else {
                    clearMap();
                    alert("No tracking data found.");
                }
            })
            .catch(err => {
                console.error("Error loading tracking data:", err);
                clearMap();
            });
        
    
}
    
$(document).ready(function () {
        $('.calendar-icon').css('display', 'block');
        $('#calendarInput').css('display', 'none');
        $('#user_id').select2({
            placeholder: "Select one or more users"
        });

        initMap();
        updateLocation();

        const urlParams = new URLSearchParams(window.location.search);
        const visitorId = urlParams.get('visitor_id');
        const userId = urlParams.get('user_id');
        const today = new Date().toISOString().split('T')[0];
        if (visitorId) {
            fetchVisitorData(visitorId, today); // ✅ Load only if visitor_id is present
        }

        if (userId) {
            fetchUserData(userId, today)
            
        }
        
        window.onbeforeunload = () => stopLiveTracking();
    });
$(document).ready(function() {
    $('#user_id').on('change', function() {
        clearMap();
        const today = new Date().toISOString().split('T')[0];
        $('.id_set h2').text($(this).find('option:selected').text());
        const selected = Array.from(this.selectedOptions).map(opt => opt.value);
        selected.forEach(userId => fetchUserData(userId, today));
    });
    $('.refresh').on('click', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const visitorId = urlParams.get('visitor_id');
        const userId = urlParams.get('user_id');
        const selectedDate = new Date().toISOString().split('T')[0];

        if (!visitorId) {
            fetchUserData(userId, selectedDate);
        }

        fetchVisitorData(visitorId, selectedDate); // Refresh map data
    })
});


    