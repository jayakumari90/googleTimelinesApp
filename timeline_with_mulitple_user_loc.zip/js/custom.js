function displayMultipleEntries(entries) {
    clearMap();
    if (!entries || entries.length === 0) return;

    let liveTracked = false;
    const timelineContainer = document.querySelector('.timeline-detail');
    timelineContainer.innerHTML = ''; // Clear timeline
    console.log('entries.timestemps[0]', entries[0].timestamps[0])
    let visitCount = 0;
    let totalKm = 0;
    let totalDurationMin = 0;
    const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
    const formatted = new Date(entries[0].timestamps[0]).toLocaleDateString('en-GB', options);
    document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');
    entries.forEach((entry, idx) => {
        const coords = entry.locations.map(p => [p.lat, p.lng]);
        const color = colors[idx % colors.length];

        const poly = drawPolyline(coords, color);
        const lastCoord = coords[coords.length - 1];

        // 🟢 Live tracking (only once, for first entry with stage == 1)
        if (entry.stage == 1 && !liveTracked) {
            // Timeline Section
        // <div class="stop-marker">📍</div>
        timelineContainer.innerHTML += `<h4 style="color:${color};">Entry ${idx + 1}</h4>`;
        if (entry.stops && entry.stops.length > 0) {
                const stops = entry.stops;
                timelineContainer.innerHTML += renderStartLocation(stops[0], "Start Point");

                for (let sIndex = 1; sIndex < stops.length; sIndex++) {
                    const prev = stops[sIndex - 1];
                    const curr = stops[sIndex];
                    const durationMin = Math.floor((new Date(curr.to) - new Date(curr.from)) / 60000);
                    totalDurationMin += durationMin;
                    const segmentKm = calculateDistance(prev.lat, prev.lng, curr.lat, curr.lng);
                    totalKm += segmentKm;
                    visitCount++;
            
                    // Driving block between stops
                    timelineContainer.innerHTML += renderDrivingBlock(prev.to, curr.from, prev, curr, curr.battery);
            
                    // Stop block
                    timelineContainer.innerHTML += renderStopBlock(curr, `Stop ${sIndex}`);
                }
            //});
            // Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
            
            document.querySelectorAll('.stop-entry').forEach(entry => {
                console.log('stop entry===', entry)
                entry.addEventListener('click', function () {
                    const lat = parseFloat(this.getAttribute('data-lat'));
                    const lng = parseFloat(this.getAttribute('data-lng'));
            
                    // Remove old marker if needed
                    if (marker) map.removeLayer(marker);
            
                    // Add new marker for clicked stop
                    marker = L.marker([lat, lng]).addTo(map).bindPopup("Selected Stop").openPopup();
                    map.setView([lat, lng], 17);
                });
            });
        } else {
            timelineContainer.innerHTML += `<div>No significant stops (3+ min)</div>`;
        }
            map.fitBounds(poly.getBounds());
            liveTracked = true;

            // Animate live marker
            startLiveTracking(coords, color); // Pass color for marker
        } else {
            // Static marker only
            // Timeline Section
        // <div class="stop-marker">📍</div>
        timelineContainer.innerHTML += `<h4 style="color:${color};">Entry ${idx + 1}</h4>`;
        if (entry.stops && entry.stops.length > 0) {
                const stops = entry.stops;
                timelineContainer.innerHTML += renderStartLocation(stops[0], "Start Point");

                for (let sIndex = 1; sIndex < stops.length; sIndex++) {
                    const prev = stops[sIndex - 1];
                    const curr = stops[sIndex];
                    const durationMin = Math.floor((new Date(curr.to) - new Date(curr.from)) / 60000);
                    totalDurationMin += durationMin;
                    const segmentKm = calculateDistance(prev.lat, prev.lng, curr.lat, curr.lng);
                    totalKm += segmentKm;
                    visitCount++;
            
                    // Driving block between stops
                    timelineContainer.innerHTML += renderDrivingBlock(prev.to, curr.from, prev, curr, curr.battery);
            
                    // Stop block
                    timelineContainer.innerHTML += renderStopBlock(curr, `Stop ${sIndex}`);
                }
            //});
            // Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
            
            document.querySelectorAll('.stop-entry').forEach(entry => {
                console.log('stop entry===', entry)
                entry.addEventListener('click', function () {
                    const lat = parseFloat(this.getAttribute('data-lat'));
                    const lng = parseFloat(this.getAttribute('data-lng'));
            
                    // Remove old marker if needed
                    if (marker) map.removeLayer(marker);
            
                    // Add new marker for clicked stop
                    marker = L.marker([lat, lng]).addTo(map).bindPopup("Selected Stop").openPopup();
                    map.setView([lat, lng], 17);
                });
            });
        } else {
            timelineContainer.innerHTML += `<div>No significant stops (3+ min)</div>`;
        }
            createColoredMarker(lastCoord, color);
        }

        
    });
    console.log('visitCount', visitCount);
    const totalDurationFormatted = formatTotalDuration(totalDurationMin);
    document.getElementById("totalVisits").innerHTML = `<strong>${visitCount}</strong> Visits<br>${totalDurationFormatted}`;
    document.getElementById("totalDistance").innerHTML = `<strong>${totalKm.toFixed(2)}</strong> km<br>${totalDurationFormatted}`;
}


// 👇 Example call
function fetchUserData(userId, selectedDate) {
    fetch(`/location/timeline/api/data.php?user_id=${userId}&date=${selectedDate}`)
        .then(res => res.json())
        .then(data => {
            if (data.entries && data.entries.length > 0) {
                displayMultipleEntries(data.entries);
            } else {
                clearMap();
                alert("No tracking data found.");
            }
        })
        .catch(err => {
            console.error("Error loading tracking data:", err);
            clearMap();
        });
}



    


function updateLocation() {
        const urlParams = new URLSearchParams(window.location.search);
        let recordId = '';
        let url = '';

        if (urlParams.get('visitor_id')) {
            recordId = urlParams.get('visitor_id');
            url = '/location/timeline/api/get_visitor_data.php';
        } else {
            recordId = urlParams.get('user_id');
            url = '/location/timeline/api/get_all_emp_data.php';
        }

        $.ajax({
            url: url,
            method: 'POST',
            data: { id: recordId },
            dataType: 'json',
            success: function (response) {
                console.log("Received JSON:", response);
                $('#user_id').html(response.data);
                const dropdown = document.getElementById('user_id');
                const userId =  response.userid;//urlParams.get('user_id');
                if (dropdown) {
                        // dropdown.val([userId]).trigger('change');
                    const optionToSelect = dropdown.querySelector(`option[value="${userId}"]`);
                    if (optionToSelect) {
                        optionToSelect.selected = true;
                    }
                }
                $('.id_set h2').text(response.username);
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
            }
        });
    }

function toggleCalendar() {
const inputDiv = document.getElementById("calendarInput");
inputDiv.style.display = inputDiv.style.display === "block" ? "none" : "block";
$('.calendar-icon').css('display', 'none');
}

function updateDate() {
    const dateValue = document.getElementById("datePicker").value;
    if (dateValue) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        const formatted = new Date(dateValue).toLocaleDateString('en-GB', options);
        document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');

        const urlParams = new URLSearchParams(window.location.search);
        const visitorId = urlParams.get('visitor_id');
        const userId = urlParams.get('user_id');

        if (visitorId) {
            // Load visitor data only
            fetchVisitorData(visitorId, dateValue);
        } else {
            const selected = $('#user_id').val(); // selected can be an array (multi-select)
            
            if (selectedUsers && selectedUsers.length > 0 && dateValue) {
                    fetchMultipleUsers(selectedUsers, dateValue);
                } else if (userId) {
                // fallback if no <select> option manually selected, use userId from URL
                fetchMultipleUsers([userId], dateValue);
            } else {
                alert("Please select one or more users.");
            }
        }
    }
}
    
let visitorPollingInterval = null;    

function stopVisitorTracking() {
    if (visitorPollingInterval) {
        clearInterval(visitorPollingInterval);
        visitorPollingInterval = null;
        console.log("🔁 Live tracking stopped.");
    }
}
    
function drawVisitorRoute(coords, color = 'blue') {
    polyline = L.polyline(coords, { color }).addTo(map);
    map.fitBounds(polyline.getBounds());
}


function fetchVisitorData(visitorId, selectedDate) {
    fetch(`/location/timeline/api/data.php?visitor_id=${visitorId}&date=${selectedDate}`)
        .then(res => res.json())
            .then(data => {
                if (data.entries && data.entries.length > 0) {
                    displayMultipleEntries(data.entries);
                } else {
                    clearMap();
                    alert("No tracking data found.");
                }
            })
            .catch(err => {
                console.error("Error loading tracking data:", err);
                clearMap();
            });
        
    
}




document.addEventListener('DOMContentLoaded', function () {
    // Ensure topbar stays visible
    const topbar = document.querySelector('.topbar');
    if (topbar) {
        topbar.style.zIndex = '10000';
        topbar.style.display = 'flex';
        topbar.style.position = 'fixed';
        topbar.style.top = '0';
        topbar.style.left = '0';
        topbar.style.width = '100%';
    }

    // Re-show topbar on any marker click
    const markerIcons = document.querySelectorAll('.leaflet-marker-icon');

    markerIcons.forEach(marker => {
        marker.addEventListener('click', function (e) {
            e.stopPropagation();
            if (topbar) {
                topbar.style.display = 'flex';
            }
        });
    });

    // Optional: Also listen for map clicks and keep topbar visible
    if (typeof map !== 'undefined') {
        map.on('click', function () {
            if (topbar) {
                topbar.style.display = 'flex';
            }
        });
    }
});


// const markerRefs = [];



function formatOption(option) {
  if (!option.id) return option.text;
  const image = $(option.element).data('image');
  return image ? $(`<span><img src="${image}" style="height:20px; margin-right:6px;" /> ${option.text}</span>`) : option.text;
}






/************************Start Multiuser Location***********************/
function startMultiLiveTracking(coords, color) {
    let index = 0;
    if (marker) map.removeLayer(marker);

    marker = L.circleMarker(coords[0], {
        radius: 8,
        fillColor: color,
        color: "#fff",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.9
    }).addTo(map);

    animationInterval = setInterval(() => {
        if (index >= coords.length) {
            clearInterval(animationInterval);
            return;
        }
        marker.setLatLng(coords[index]);
        index++;
    }, 1000);
}





function displayMultipleUserEntries(entries) {
    clearMap();
    if (!entries || entries.length === 0) return;

    const timelineContainer = document.querySelector('.timeline-detail');
    timelineContainer.innerHTML = '';

    let liveTracked = false;
    let visitCount = 0;
    let totalKm = 0;
    let totalDurationMin = 0;

    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    const formatted = new Date(entries[0].timestamps[0]).toLocaleDateString('en-GB', options);
    document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');

    entries.forEach((entry, idx) => {
        const color = colors[idx % colors.length];
        const validLocations = entry.locations.filter(p => p.lat && p.lng);
        if (validLocations.length === 0) return;

        const coords = validLocations.map(p => [p.lat, p.lng]);
        const lastCoord = coords[coords.length - 1];

        createImageMarker(lastCoord[0], lastCoord[1], entry.profile, entry.name);
        const poly = drawPolyline(coords, color);
        if (!poly) return;

        timelineContainer.innerHTML += `<h4 style="color:${color};">${entry.name || 'Entry'} (${idx + 1})</h4>`;

        if (entry.stage === 1 && !liveTracked && !mapAlreadyZoomed) {
            const center = poly.getBounds().getCenter();
            map.setView(center, 13);
            mapAlreadyZoomed = true;
            liveTracked = true;
            startLiveTracking(coords, color);
        }
    });

    // Distance/Duration summary (optional)
    const totalDurationFormatted = formatTotalDuration(totalDurationMin);
    document.getElementById("totalVisits").innerHTML = `<strong>${visitCount}</strong> Visits<br>${totalDurationFormatted}`;
    document.getElementById("totalDistance").innerHTML = `<strong>${totalKm.toFixed(2)}</strong> km<br>${totalDurationFormatted}`;
}



// 🚀 Fetch multiple users at once
function fetchMultipleUsers(userIds, selectedDate) {
    if (!Array.isArray(userIds) || userIds.length === 0) return;
    const params = new URLSearchParams();
    userIds.forEach(id => params.append('user_id[]', id));
    params.append('date', selectedDate);

    fetch(`/location/timeline/api/get_multiple_loc.php?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            if (data.entries && data.entries.length > 0) {
                displayMultipleUserEntries(data.entries);
            } else {
                clearMap();
                alert("No tracking data found.");
            }
        })
        .catch(err => {
            console.error("Error loading tracking data:", err);
            clearMap();
        });
}


/******************************End Multiuser Location********************************/

    
$(document).ready(function () {
    $('#project_status').select2({
        placeholder: "Select Project/Branch",
        templateResult: formatOption,
        templateSelection: formatOption,
        width: '100%'
    });
    
    $('.calendar-icon').css('display', 'block');
    $('#calendarInput').css('display', 'none');
    $('#user_id').select2({
        placeholder: "Select user(s)",
        allowClear: true,
        templateResult: formatOption,
        templateSelection: formatOption
    }).on('change', function () {
        const selectedUsers = $(this).val();
        const dateValue = document.getElementById("datePicker").value;
        if (selectedUsers && selectedUsers.length > 0 && dateValue) {
            fetchMultipleUsers(selectedUsers, dateValue); // ✅ only on valid selection
        }
    });

    initMap();
    updateLocation();

    const urlParams = new URLSearchParams(window.location.search);
    const visitorId = urlParams.get('visitor_id');
    const userId = urlParams.get('user_id');
    const today = new Date().toISOString().split('T')[0];
    if (visitorId) {
        fetchVisitorData(visitorId, today); // ✅ Load only if visitor_id is present
        getAllProjects('',visitorId)
    }

    if (userId) {
        fetchUserData(userId, today)
        getAllProjects(userId,'')
        
    }
    
    window.onbeforeunload = () => stopLiveTracking();
});

$(document).ready(function() {
     $('#user_id').on('change', function () {
        const selected = $(this).val(); // Array of user_ids
        if (selected && selected.length > 0) {
            const today = new Date().toISOString().split('T')[0];
            fetchMultipleUsers(selected, today);
        }
    });
    
    
    $('.refresh').on('click', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const visitorId = urlParams.get('visitor_id');
        const userId = urlParams.get('user_id');
        const selectedDate = new Date().toISOString().split('T')[0];

        if (!visitorId) {
            fetchUserData(userId, selectedDate);
        }

        fetchVisitorData(visitorId, selectedDate); // Refresh map data
    })
});


    