let map;
let marker = null;
const polylineRefs = [];
const markerRefs = [];
let animationInterval = null;
const colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown'];
let mapAlreadyZoomed = false;

function initMap() {
    map = L.map('map', {
        zoomControl: true,
        zoomSnap: 0.5,
        minZoom: 4,
        maxZoom: 18
    }).setView([26.9124, 75.7873], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
}

function clearMap() {
    if (marker) {
        map.removeLayer(marker);
        marker = null;
    }

    polylineRefs.forEach(p => map.removeLayer(p));
    polylineRefs.length = 0;

    markerRefs.forEach(m => map.removeLayer(m));
    markerRefs.length = 0;

    mapAlreadyZoomed = false;
}

function drawPolyline(coords, color) {
    if (!coords || coords.length === 0) return null;
    const polyline = L.polyline(coords.map(p => [p[0], p[1]]), { color }).addTo(map);
    polylineRefs.push(polyline);
    return polyline;
}

function resetMapView() {
    map.setView([26.9124, 75.7873], 13);
    initialViewSet = false;
}

function startLiveTracking(coords, color = 'blue') {
    let index = 0;
    if (marker) map.removeLayer(marker);

    marker = L.circleMarker(coords[0], {
        radius: 8,
        fillColor: color,
        color: "#fff",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.9
    }).addTo(map);

    animationInterval = setInterval(() => {
        if (index >= coords.length) {
            clearInterval(animationInterval);
            return;
        }
        marker.setLatLng(coords[index]);
        index++;
    }, 1000);
}

function createImageMarker(lat, lng, imageUrl, userName = '', geolocation = '') {
    const customHtml = `
        <div class="map-pin-wrapper" title="${userName}">
            <div class="map-pin-circle">
                <img src="${imageUrl}" alt="${userName}">
            </div>
            <div class="map-pin-tail"></div>
            <div class="map-pin-dot"></div>
        </div>`;

    const icon = L.divIcon({
        className: '',
        html: customHtml,
        iconSize: [50, 70],
        iconAnchor: [25, 70]
    });

    const marker = L.marker([lat, lng], { icon }).addTo(map);

    // Popup with image, name, and address
    const popupHtml = `
        <div style="display: flex; align-items: center;">
            <img src="${imageUrl}" style="width:40px;height:40px;border-radius:50%;margin-right:10px;">
            <div>
                <strong>${userName}</strong><br>
                <div style="max-width:250px;font-size:13px;">${geolocation}</div>
            </div>
        </div>
    `;

    marker.bindPopup(popupHtml).openPopup();
    markerRefs.push(marker);
    return marker;
}

// function drawPolyline(coords, color) {
//     const polyline = L.polyline(coords, { color, weight: 4 }).addTo(map);
//     polylineRefs.push(polyline);
//     return polyline;
// }

function createColoredMarker(position, color = 'blue') {
    const icon = L.icon({
        iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
        shadowSize: [41, 41]
    });
    const m = L.marker(position, { icon }).addTo(map);
    markerRefs.push(m);
    return m;
}

function startLiveTracking(coords, color) {
    let index = 0;
    if (marker) map.removeLayer(marker);

    marker = L.circleMarker(coords[0], {
        radius: 8,
        fillColor: color,
        color: "#fff",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.9
    }).addTo(map);

    animationInterval = setInterval(() => {
        if (index >= coords.length) {
            clearInterval(animationInterval);
            return;
        }
        marker.setLatLng(coords[index]);
        index++;
    }, 1000);
}


    

function stopUserTracking() {
    if (userPollingInterval) {
        clearInterval(userPollingInterval);
        userPollingInterval = null;
        console.log("🛑 User live tracking stopped.");
    }
}

function formatTime12Hour(datetime) {
    const date = new Date(datetime);
    return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

function calculateDuration(from, to) {
    const fromTime = new Date(from);
    const toTime = new Date(to);
    const diffMs = toTime - fromTime;
    const diffMins = Math.floor(diffMs / 60000); // total minutes

    const hours = Math.floor(diffMins / 60);
    const minutes = diffMins % 60;

    if (hours > 0) {
        return `${hours} hr${hours > 1 ? 's' : ''} ${minutes} min`;
    } else {
        return `${minutes} min`;
    }
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of Earth in KM

    // Round to 5 decimal places to avoid noise in GPS drift
    lat1 = +lat1.toFixed(5);
    lon1 = +lon1.toFixed(5);
    lat2 = +lat2.toFixed(5);
    lon2 = +lon2.toFixed(5);

    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    const distance = R * c;
    return distance < 0.05 ? 0 : distance; // Ignore distances < 50m as noise
}

// function calculateDistance(lat1, lon1, lat2, lon2) {
//     const R = 6371;
//     const dLat = ((lat2 - lat1) * Math.PI) / 180;
//     const dLon = ((lon2 - lon1) * Math.PI) / 180;
//     const a =
//         Math.sin(dLat / 2) ** 2 +
//         Math.cos((lat1 * Math.PI) / 180) *
//         Math.cos((lat2 * Math.PI) / 180) *
//         Math.sin(dLon / 2) ** 2;
//     const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//     return R * c;
// }

// Format a location block like "THE RING RESIDENCY..." etc.
function renderStartLocation(stop, label = "Start Location") {
    const time = formatTime12Hour(stop.from);
    return `
        <div class="stop-entry" data-lat="${stop.lat}" data-lng="${stop.lng}" style="cursor:pointer;">
            <div class="stop-marker">📍</div>
            <strong>${label}</strong><br>
            Left at ${time}<br>
        </div>`;
}

// Format a driving block like "Driving\n17km · 54 min\n8:59 am – 9:53 am"
function renderDrivingBlock(from, to, fromCoord, toCoord, battery) {
    const distance = calculateDistance(fromCoord.lat, fromCoord.lng, toCoord.lat, toCoord.lng).toFixed(2);
    const duration = calculateDuration(from, to);
    const fromTime = formatTime12Hour(from);
    const toTime = formatTime12Hour(to);
    console.log('toCoord', toCoord);
    return `
        <div class="stop-entry" data-lat="${toCoord.lat}" data-lng="${toCoord.lng}" style="cursor:pointer;">
            <div class="stop-marker">🚗</div>
            <strong>Driving</strong><br>
            ${distance} km · ${duration}<br>
            ${fromTime} – ${toTime}<br>
            ${battery}<br>
            <span>Duration: ${duration} </span><br>
        </div>`;
}

// Format a stop like "Visited Anuda?\n9:53 am – 2:14 pm"
function renderStopBlock(stop, label = "") {
    const fromTime = formatTime12Hour(stop.from);
    const toTime = formatTime12Hour(stop.to);
    const duration = calculateDuration(stop.from, stop.to);

    return `
        <div class="stop-entry" data-lat="${stop.lat}" data-lng="${stop.lng}" style="cursor:pointer;">
            <div class="stop-marker">📍</div>
            <strong>${label || `Visited?`}</strong><br>
            ${fromTime} – ${toTime}<br>
            ${stop.battery}<br>
            <span>Duration: ${duration} </span><br>
        </div>`;
}


function formatTotalDuration(mins) {
    const hrs = Math.floor(mins / 60);
    const rem = mins % 60;
    return hrs > 0 ? `${hrs} hr${hrs > 1 ? 's' : ''} ${rem} min` : `${rem} min`;
}