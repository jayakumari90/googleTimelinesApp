let cachedProjects = {
  branches: [],
  upcomming: [],
  livedeals: [],
  wondeals: []
};

function getAllProjects(userId, visitorId){
    $.ajax({
        url: '/location/timeline/api/our_projects.php',
        method: 'GET',
        data: { assigned_id: userId, visitor_id: visitorId },
        success: function(response) {
            console.log("Full project response:", response);

            if (response.status === 'success') {
                cachedProjects = {
                  branches: response.branches || [],
                  livedeals: response.livedeals || [],
                  upcomming: response.upcomming || [],
                  wondeals: response.wondeals || []
                };
        
                renderSelectedProjects();
                const branches = response.branches;
                if (Array.isArray(branches)) {
                    branches.forEach((b, i) => {
                        console.log(`Branch ${i + 1}:`, b);
                    });
                    plotBranchLocations(branches); // ✅ Add project markers to map
                } else {
                    console.warn("branches is not an array:", branches);
                }
                const livedeals = response.livedeals;
                if (Array.isArray(livedeals)) {
                    livedeals.forEach((b, i) => {
                        console.log(`livedeals ${i + 1}:`, b);
                    });
                    plotProjectLocations(livedeals); // ✅ Add project markers to map
                } else {
                    console.warn("livedeals is not an array:", livedeals);
                }
                const upcomming = response.upcomming;
                if (Array.isArray(upcomming)) {
                    upcomming.forEach((b, i) => {
                        console.log(`upcomming ${i + 1}:`, b);
                    });
                    plotUpcommingLocations(upcomming); // ✅ Add project markers to map
                } else {
                    console.warn("upcomming is not an array:", livedeals);
                }
                const wondeals = response.wondeals;
                if (Array.isArray(wondeals)) {
                    wondeals.forEach((b, i) => {
                        console.log(`wondeals ${i + 1}:`, b);
                    });
                    plotCompletedLocations(wondeals); // ✅ Add project markers to map
                } else {
                    console.warn("wondeals is not an array:", wondeals);
                }
            } else {
                alert("Error: " + response.message);
            }
        },
        error: function(err) {
            console.error("AJAX error", err);
        }
    });
}


function plotBranchLocations(branches) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/anuda.png',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -30]
    });

    const bounds = L.latLngBounds([]);

    branches.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.branch_name || "Project"}</strong><br>
                    ${project.branch_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}



function plotProjectLocations(projects) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/live_projects.png',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -30]
    });

    const bounds = L.latLngBounds([]);
    console.log('projects', projects)
    projects.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.deal_name || "Project"}</strong><br>
                    ${project.deal_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}

function plotUpcommingLocations(projects) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/comming_soon-removebg-preview.png',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -30]
    });

    const bounds = L.latLngBounds([]);
    console.log('projects', projects)
    projects.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.deal_name || "Project"}</strong><br>
                    ${project.deal_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}

function plotCompletedLocations(projects) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/won.png',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -30]
    });

    const bounds = L.latLngBounds([]);
    console.log('projects', projects)
    projects.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.deal_name || "Project"}</strong><br>
                    ${project.deal_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}

function renderSelectedProjects() {
  clearAllMarkers(); // ✅ Optional: remove previous ones

  const selected = $('#project_status').val(); // array

  if (selected.includes('branch')) {
    plotBranchLocations(cachedProjects.branches);
  }
  if (selected.includes('inprogress')) {
    plotProjectLocations(cachedProjects.livedeals);
  }
  if (selected.includes('upcomming')) {
    plotUpcommingLocations(cachedProjects.upcomming);
  }
  
}

function clearAllMarkers() {
  if (Array.isArray(markerRefs)) {
    markerRefs.forEach(marker => map.removeLayer(marker));
    markerRefs.length = 0; // ✅ Clears array without reassigning
  }
}

$(document).ready(function(){
    $('#project_status').on('change', function () {
      renderSelectedProjects();
      if (selected.includes('completed')) {
        plotCompletedLocations(cachedProjects.wondeals);
      }
    });
})