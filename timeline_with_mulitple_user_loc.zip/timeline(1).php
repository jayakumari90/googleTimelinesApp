<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Dashboard Clone</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html,
        body {
            height: 100%;
            font-family: 'Segoe UI', sans-serif;
        }
        
        .topbar {
            display: flex;
            align-items: center;
            padding: 6px 12px;
            background-color: #fff;
            border-bottom: 1px solid #ddd;
        }
        
        .topbar .left {
            font-size: 16px;
        }
        
        .topbar .left span {
            color: #0093d0;
            font-size: 1.2em;
        }
        
        .topbar .center select {
            padding: 5px 8px;
            font-size: 13px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        
        .topbar .right {
            background: #00a3e1;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .topbar .right img {
            width: 16px;
        }
        
        #map {
            height: calc(100% - 40px);
            width: 100%;
            z-index: 1;
        }
        
        .travel-box {
            position: absolute;
            top: 55px;
            left: 14px;
            z-index: 100;
        }
        
        .travel-box .refresh img {
            width: auto;
        }
        
        .travel-box .btns {
            background: #fff;
            box-shadow: 0 0px 2px rgba(0, 0, 0, 0.2);
            border-radius: 4px;
            overflow: hidden;
            display: inline-flex;
            margin-bottom: 5px;
        }
        
        .travel-box button {
            display: block;
            width: auto;
            padding: 8px 12px;
            background: white;
            border: none;
            border-bottom: 1px solid #eee;
            font-size: 18px;
            text-align: left;
            cursor: pointer;
            border-right: 1px solid #eee;
        }
        
        .travel-box button:last-child {
            border-bottom: none;
        }
        
        .travel-box button.active {
            background: #f0f0f0;
            font-weight: 600;
        }
        
        .sidebar {
            position: absolute;
            top: 55px;
            right: 20px;
            width: 358px;
            border-radius: 6px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            z-index: 100;
            background: #fff;
        }
        
        .sidebar .header {
            background: #0093d0;
            color: #fff;
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            border-bottom: 1px solid #88C7DE;
        }
        
        .smart_p img {
            width: 23px;
            height: 29px;
        }
        
        .sidebar .stats {
            background: #0093d0;
            color: #fff;
            display: flex;
            justify-content: space-between;
            padding: 12px 10px;
            font-size: 12px;
        }
        
        .sidebar .stats div {
            text-align: center;
            flex: 1;
        }
        
        .sidebar .timeline {
            background: #fff;
            padding: 10px 16px;
            font-size: 12px;
        }
        
        .timeline .title {
            font-weight: 600;
            color: #444;
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
        }
        
        .timeline .pending {
            color: #999;
        }
        
        .user-select-container {
            display: flex;
            align-items: center;
            gap: 8px;
            width: 450px;
            position: relative;
            margin-left : 8px;
        }
        
        .input-wrapper {
            position: relative;
            flex: 1;
            display: flex;
            margin-left: 10px;
        }
        
        .user-select-container input[type="text"] {
            width: 100%;
            padding: 6px 0px 8px 12px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 14px;
        }
        
        .dropdown-arrow {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            pointer-events: none;
            width: 14px;
            height: 14px;
        }
        
        .search-icon {
            width: 30px;
            height: 30px;
            background-color: #00a3e1;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        
        .search-icon img {
            width: 14px;
            height: 14px;
            filter: brightness(0) invert(1);
        }
        
        .dropdown-list {
            position: absolute;
            top: 40px;
            left: 0;
            right: 38px;
            background: #fff;
            border: 1px solid #ccc;
            border-top: none;
            border-radius: 0 0 6px 6px;
            max-height: 150px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }
        
        .dropdown-list div {
            padding: 8px 12px;
            cursor: pointer;
        }
        
        .dropdown-list div:hover {
            background-color: #f1f1f1;
        }
        
        .avatar img {
            border-radius: 50%;
            border: 1px solid #fff;
            margin-right: 10px;
        }
        
        .main_part {
            display: flex;
        }
        
        .data_set {
            width: 95px;
            display: table-cell;
            font-size: 13px;
            text-align: center;
            color: #fff;
            border-right: 1px solid #88c7de;
            margin-right: 8px;
            height: 68px;
        }
        
        .tabs2 {
            background-color: #eaeaea;
            text-align: center;
            padding: 15px 0;
            position: relative;
            height: 250px;
            margin-bottom: 15px;
        }
        
        .tabs2::before,
        .tabs2::after {
            content: "";
            display: inline-block;
            width: 25%;
            height: 1px;
            background-color: #ccc;
            vertical-align: middle;
        }
        
        #dismiss {
            background-image: url(img/portlet-remove-icon-white.png);
            background-repeat: no-repeat;
            background-color: #0088b9;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            left: 4px;
            background-position: center;
            position: absolute;
            left: -31px;
        }
        .user_filter{
            width: 100%;
        }
    </style>
</head>

<body>
    <?php // Only if you're embedding inside iframe (optional)
header("X-Frame-Options: ALLOW-FROM https://*.bitrix24.com");
?>
    <div class="topbar">
        <div class="left">Team / <span>My Team</span> </div>

        <div class="user-select-container">
            <!-- <div class="input-wrapper">
                <input type="text" id="userInput" placeholder="Select User" oninput="filterUsers()" onfocus="showDropdown()" />
                <img class="dropdown-arrow" src="https://cdn-icons-png.flaticon.com/512/2985/2985150.png" alt="dropdown arrow">
            </div> -->

            <select class="form-control user_filter"  name="user_id[]" id="user_id" size="6">

                </select>
            <!-- <div class="search-icon">
                <img src="https://cdn-icons-png.flaticon.com/512/54/54481.png" alt="search">
            </div> -->
            
        </div>

    </div>

    <div id="map"></div>

    <div class="travel-box">
        <div class="btns">
            <button class="active" onclick="setView(this)">Map</button>
            <button onclick="setView(this)">Satellite</button>
        </div>
        <div class="btns">
            <button onclick="setView(this)">Travel View</button>
            <button onclick="setView(this)">Location View</button>
        </div>
        <div class="refresh">
            <a href="#"><img src="img/refresh.png" alt="refresh"></a>
        </div>
    </div>

    <div class="sidebar">
        <div id="dismiss" onclick="backToPreviousPage();" class="hideTimeLineClass"><i class="glyphicon glyphicon-arrow-right" id="change_arrow"></i></div>
        <div class="header">
            <div class="main_part">
                <div class="avatar">
                    <img alt="" src="img/usrsml_29.png" onerror="this.src='img/usrsml_29.png';">
                </div>
                <div class="id_set">
                    <h2></h2>
                </div>
            </div>
            <div class="smart_p">
                <img src="img/smartphone.png" alt="user">
            </div>
        </div>
        <div class="stats">
            <div class="data_set"><strong>0%</strong><br>FTR</div>
            <div class="data_set2"><img src="img/visit.png">
                <br>
                <strong>0</strong> Visits<br> 0 min</div>
            <div class="data_set2"><img src="img/kms.png"> <br> <strong>0</strong> Kms <br>0 min</div>
            <div class="data_set2"><img src="img/office.png"> <br> <strong>Office</strong><br>0 min</div>
        </div>
        <div class="timeline">
            <div class="title">
                <span>TIMELINE</span>
                <span id="selectedDate"><?php echo date('d F Y')?></span>
                <div class="calendar-wrapper">
                    <i class="fa-regular fa-calendar calendar-icon" onclick="toggleCalendar()"></i>
                    <div class="calendar-input" id="calendarInput">
                        <input type="date" id="datePicker" onchange="updateDate()">
                    </div> 
                </div>
            </div>
            <div class="timeline-detail"></div>
        </div>
        <div class="tabs2">
            <span>PENDING VISITS</span>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<!-- Leaflet CDN (no API key needed) -->
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<script>
    
    let map, marker, polyline, animationInterval;

    function initMap() {
        map = L.map('map').setView([21.218, 74.833], 14);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
    }

    function clearMap() {
        if (marker) {
            map.removeLayer(marker);
            marker = null;
        }
        if (polyline) {
            map.removeLayer(polyline);
            polyline = null;
        }
        if (animationInterval) {
            clearInterval(animationInterval);
            animationInterval = null;
        }
    }

    function drawRoute(coords, color = 'blue') {
        polyline = L.polyline(coords, { color }).addTo(map);
        map.fitBounds(polyline.getBounds());
    }

    function startLiveTracking(points) {
        if (!points || points.length === 0) return;

        let index = 0;
        marker = L.marker(points[index]).addTo(map);

        animationInterval = setInterval(() => {
            index++;
            if (index >= points.length) {
                clearInterval(animationInterval);
                return;
            }
            marker.setLatLng(points[index]);
        }, 10000);
    }
    let visitorPollingInterval = null;

    function stopVisitorTracking() {
        if (visitorPollingInterval) {
            clearInterval(visitorPollingInterval);
            visitorPollingInterval = null;
            console.log("🔁 Live tracking stopped.");
        }
    }
    
    let userPollingInterval = null;

function stopUserTracking() {
    if (userPollingInterval) {
        clearInterval(userPollingInterval);
        userPollingInterval = null;
        console.log("🛑 User live tracking stopped.");
    }
}
    // function fetchUserData(userId, selectedDate) {
    //     fetch(`/location/timeline/api/data.php?user_id=${userId}&date=${selectedDate}`)
    //         .then(res => res.json())
    //                 .then(data => {
    //                     console.log("Response:", data);
    //                     const timelineContainer = document.querySelector('.timeline-detail');
    
    //                     const coords = (data.locations || []).map(p => [parseFloat(p.lat), parseFloat(p.lng)]);
    //                     if (coords.length === 0) { timelineContainer.innerHTML =  `<div style="margin-bottom:10px;">No Record Found</div>`};
    
    //                     const stage = parseInt(data.stage || 0);
    
    //                     clearMap();
    
    //                     drawRoute(coords, stage === 1 ? 'green' : 'black');
    //                     let timelineHtml = '';//`<span>TIMELINE</span><br><br>`;
    //                     const rawDate = data.timestamps[0]; // "2025-06-23 18:39:53"
    //                     const dateObj = new Date(rawDate);
    
    //                     // Format: 06 June 2025
    //                     const options = { day: '2-digit', month: 'long', year: 'numeric' };
    //                     const formattedDate = dateObj.toLocaleDateString('en-GB', options);
    
    //                     document.querySelector('#selectedDate').innerHTML = formattedDate;
    
    //                     data.timestamps.forEach((time, index) => {
    //                         const point = data.locations[index];
    //                         timelineHtml += `
    //                             <div style="margin-bottom:10px;">
    //                             <strong>${time}</strong><br>
    //                             Lat: ${point.lat.toFixed(5)}, Lng: ${point.lng.toFixed(5)}
    //                             </div>`;
    //                     });
    //                     timelineContainer.innerHTML = timelineHtml;
    //                     if (stage === 1) {
    //                         startLiveTracking(coords);
    //                     }
    //                 })
    //                 .catch(err => console.error("Error:", err));
    // }

    // function fetchVisitorData(visitorId, selectedDate) {
    //     fetch(`/location/timeline/api/data.php?visitor_id=${visitorId}&date=${selectedDate}`)
    //         .then(res => res.json())
    //             .then(data => {
    //                 console.log("Response:", data);

    //                 const coords = (data.locations || []).map(p => [parseFloat(p.lat), parseFloat(p.lng)]);
    //                 if (coords.length === 0) return;

    //                 const stage = parseInt(data.stage || 0);

    //                 clearMap();

    //                 drawRoute(coords, stage === 1 ? 'green' : 'black');
    //                 const timelineContainer = document.querySelector('.timeline-detail');
    //                 let timelineHtml = `<span>TIMELINE</span><br><br>`;
    //                 data.timestamps.forEach((time, index) => {
    //                     const point = data.locations[index];
    //                     timelineHtml += `
    //                         <div style="margin-bottom:10px;">
    //                         <strong>${time}</strong><br>
    //                         Lat: ${point.lat.toFixed(5)}, Lng: ${point.lng.toFixed(5)}
    //                         </div>`;
    //                 });
    //                 timelineContainer.innerHTML = timelineHtml;
    //                 if (stage === 1) {
    //                     startLiveTracking(coords);
    //                 }
    //             })
    //             .catch(err => console.error("Error:", err));
    // }
    function fetchUserData(userId, selectedDate) {
        stopUserTracking(); // always stop previous polling first
    
        function poll() {
            fetch(`/location/timeline/api/data.php?user_id=${userId}&date=${selectedDate}`)
                .then(res => res.json())
                .then(data => {
                    console.log("Polling User Data:", data);
                    const timelineContainer = document.querySelector('.timeline-detail');
    
                    const coords = (data.locations || []).map(p => [parseFloat(p.lat), parseFloat(p.lng)]);
                    const stage = parseInt(data.stage || 0);
    
                    if (coords.length === 0) {
                        timelineContainer.innerHTML = `<div style="margin-bottom:10px;">No Record Found</div>`;
                        clearMap();
                        stopUserTracking();
                        return;
                    }
    
                    clearMap();
                    drawRoute(coords, stage === 1 ? 'green' : 'black');
    
                    // Format date
                    const rawDate = data.timestamps[0];
                    const dateObj = new Date(rawDate);
                    const options = { day: '2-digit', month: 'long', year: 'numeric' };
                    const formattedDate = dateObj.toLocaleDateString('en-GB', options);
                    document.querySelector('#selectedDate').innerHTML = formattedDate;
    
                    // Update timeline
                    let timelineHtml = '';
                    if (data.stops && data.stops.length > 0) {
                        data.stops.forEach((stop, index) => {
                            timelineHtml += `
                                <div style="margin-bottom:10px;">
                                    <strong>Stop ${index + 1}</strong><br>
                                    From: ${stop.from}<br>
                                    To: ${stop.to}<br>
                                    Duration: ${stop.duration_min} mins<br>
                                    Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
                                </div>`;
                        });
                    } else {
                        timelineHtml += `<div>No significant stops (5+ min) found</div>`;
                    }
                    timelineContainer.innerHTML = timelineHtml;
    
                    // Set or move marker
                    const lastCoord = coords[coords.length - 1];
                    if (!marker) {
                        marker = L.marker(lastCoord).addTo(map);
                    } else {
                        marker.setLatLng(lastCoord);
                    }
                    map.setView(lastCoord, 15);
    
                    // Stop polling if stage is not live
                    if (stage !== 1) {
                        stopUserTracking();
                    }
                })
                .catch(err => {
                    console.error("Polling Error:", err);
                    stopUserTracking();
                });
        }
    
        // Initial call
        poll();
    
        // Start interval polling
        userPollingInterval = setInterval(poll, 10000); // every 10 seconds
    }
    function fetchVisitorData(visitorId, selectedDate) {
        stopVisitorTracking(); // Always stop previous interval before starting new one
    
        function poll() {
            fetch(`/location/timeline/api/data.php?visitor_id=${visitorId}&date=${selectedDate}`)
                .then(res => res.json())
                .then(data => {
                    console.log("Polling Response:", data);
    
                    const coords = (data.locations || []).map(p => [parseFloat(p.lat), parseFloat(p.lng)]);
                    const stage = parseInt(data.stage || 0);
                    const timelineContainer = document.querySelector('.timeline-detail');
    
                    // If no coordinates found
                    if (coords.length === 0) {
                        timelineContainer.innerHTML = `<div style="margin-bottom:10px;">No Record Found</div>`;
                        clearMap();
                        stopVisitorTracking(); // no need to poll further
                        return;
                    }
    
                    // If not stage 1 (live), then stop tracking and show static data
                    if (stage !== 1) {
                        console.log("Stage is not 1, stopping live tracking.");
                        stopVisitorTracking(); // stop if previously started
                    }
    
                    clearMap();
                    drawRoute(coords, stage === 1 ? 'green' : 'black');
    
                    // Update Timeline
                    let timelineHtml = `<span>TIMELINE</span><br><br>`;
                   if (data.stops && data.stops.length > 0) {
                        data.stops.forEach((stop, index) => {
                            timelineHtml += `
                                <div style="margin-bottom:10px;">
                                    <strong>Stop ${index + 1}</strong><br>
                                    From: ${stop.from}<br>
                                    To: ${stop.to}<br>
                                    Duration: ${stop.duration_min} mins<br>
                                    Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
                                </div>`;
                        });
                    } else {
                        timelineHtml += `<div>No significant stops (5+ min) found</div>`;
                    }
                    timelineContainer.innerHTML = timelineHtml;
    
                    // Update marker
                    const lastCoord = coords[coords.length - 1];
                    if (!marker) {
                        marker = L.marker(lastCoord).addTo(map);
                    } else {
                        marker.setLatLng(lastCoord);
                    }
                    map.setView(lastCoord, 15);
                })
                .catch(err => {
                    console.error("Polling Error:", err);
                    stopVisitorTracking();
                });
        }
    
        // Initial fetch
        poll();
    
        // Start polling only if stage will be 1 (checked inside poll function)
        visitorPollingInterval = setInterval(poll, 10000); // 10 seconds
    }

    


    function updateLocation() {
        const urlParams = new URLSearchParams(window.location.search);
        let recordId = '';
        let url = '';

        if (urlParams.get('visitor_id')) {
            recordId = urlParams.get('visitor_id');
            url = '/location/timeline/api/get_visitor_data.php';
        } else {
            recordId = urlParams.get('user_id');
            url = '/location/timeline/api/get_all_emp_data.php';
        }

        $.ajax({
            url: url,
            method: 'POST',
            data: { id: recordId },
            dataType: 'json',
            success: function (response) {
                console.log("Received JSON:", response);
                $('#user_id').html(response.data);
                $('.id_set h2').text(response.username);
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
            }
        });
    }

    function toggleCalendar() {
            const inputDiv = document.getElementById("calendarInput");
            inputDiv.style.display = inputDiv.style.display === "block" ? "none" : "block";
            $('.calendar-icon').css('display', 'none');
        }

    function updateDate() {
        const dateValue = document.getElementById("datePicker").value;
        if (dateValue) {
            const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
            const formatted = new Date(dateValue).toLocaleDateString('en-GB', options);
            document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');

            // 🔁 Refetch data for all selected users
            const urlParams = new URLSearchParams(window.location.search);
            const visitorId = urlParams.get('visitor_id');
            const userId = urlParams.get('user_id');
            console.log('visitorId', visitorId, 'userId', userId)

            if (visitorId) {
                fetchVisitorData(visitorId, dateValue); // ✅ Load only if visitor_id is present
            }else{

                const selected = $('#user_id').val();
                console.log('userrrrr ', selected);
                console.log('dateValue ', dateValue);
                // selected.forEach(uid => fetchUserData(uid, dateValue));
                fetchUserData(selected, dateValue)
            }
        }
    }

    $(document).ready(function () {
        $('.calendar-icon').css('display', 'block');
        $('#calendarInput').css('display', 'none');
        $('#user_id').select2({
            placeholder: "Select one or more users"
        });

        initMap();
        updateLocation();

        const urlParams = new URLSearchParams(window.location.search);
        const visitorId = urlParams.get('visitor_id');
        const userId = urlParams.get('user_id');

        if (visitorId) {
            fetchVisitorData(visitorId, '<?php echo date('Y-m-d')?>'); // ✅ Load only if visitor_id is present
        }

        if (userId) {
            fetchUserData(userId, '<?php echo date('Y-m-d')?>')
            $('#user_id').on('change', function () {
                clearMap();
                
                $('.id_set h2').text($(this).find('option:selected').text());
                const selected = Array.from(this.selectedOptions).map(opt => opt.value);
                selected.forEach(userId => fetchUserData(userId, '<?php echo date('Y-m-d')?>'));
            });
        }
    });

    window.onbeforeunload = () => stopLiveTracking();
</script>

</body>

</html>