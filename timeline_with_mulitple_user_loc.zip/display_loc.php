<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Visitor Location Timeline</title>
    <style>
        html, body {
            margin: 0;
            height: 100%;
            font-family: Arial, sans-serif;
        }
        #container {
            display: flex;
            height: 100vh;
        }
        #timeline {
            width: 35%;
            padding: 15px;
            box-sizing: border-box;
            overflow-y: auto;
            background-color: #f4f4f4;
            border-right: 1px solid #ccc;
        }
        #timeline h3 {
            margin-top: 0;
        }
        .location-entry {
            background: #fff;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        #map {
            flex: 1;
        }
    </style>
</head>
<body>
    <div id="container">
        <div id="timeline">
            <h3>Location Timeline</h3>
            <div id="locationList">Loading...</div>
        </div>
        <div id="map"></div>
    </div>

    <script>
    let map, marker, polyline;
    let currentIndex = 0;
    let animationInterval;

    // ✅ Get visitor_id from URL
    const urlParams = new URLSearchParams(window.location.search);
    const recordId = urlParams.get('visitor_id') || 8831;
    console.log('recordId===', recordId)

    function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: { lat: 26.9124, lng: 75.7873 }, // default Jaipur center
        });

        marker = new google.maps.Marker({
            map: map,
            icon: {
                url: "https://anuda.net/location/img/bike.png", // Bike icon
                scaledSize: new google.maps.Size(50, 50)
            },
            title: "Moving Bike"
        });

        fetchAndAnimate();
        setInterval(fetchAndAnimate, 5000);
    }

    let previousPath = [];

    async function fetchAndAnimate() {
        const res = await fetch(`/location/api/data.php?id=${recordId}`);
        const data = await res.json();

        if (!data.locations || data.locations.length < 2) {
            console.log("Not enough points to animate");
            return;
        }

        const path = data.locations;
        const timestamps = data.timestamps;

        if (JSON.stringify(path) === JSON.stringify(previousPath)) return;
        previousPath = path;

        if (polyline) polyline.setMap(null);

        polyline = new google.maps.Polyline({
            path: path,
            strokeColor: "#007BFF",
            strokeOpacity: 0.8,
            strokeWeight: 4,
            map: map
        });

        currentIndex = 0;
        animateMarker(path);
        updateTimeline(path, timestamps);
    }

    function animateMarker(path) {
        if (animationInterval) clearInterval(animationInterval);
        marker.setPosition(path[0]);
        map.setCenter(path[0]);

        animationInterval = setInterval(() => {
            currentIndex++;
            if (currentIndex >= path.length) {
                clearInterval(animationInterval);
                return;
            }
            marker.setPosition(path[currentIndex]);
            map.panTo(path[currentIndex]);
        }, 800);
    }

    async function updateTimeline(path, timestamps) {
        const locationList = document.getElementById('locationList');
        locationList.innerHTML = '';

        for (let i = path.length - 1; i >= 0; i--) {
            const { lat, lng } = path[i];
            const time = timestamps[i];
            const address = await getAddress(lat, lng);
            const div = document.createElement('div');
            div.className = 'location-entry';
            div.innerHTML = `
                ${address}<br>
                <small>${new Date(time).toLocaleString()}</small>
            `;
            locationList.appendChild(div);
        }
    }

    async function getAddress(lat, lng) {
        try {
            const res = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=YOUR_API_KEY`);
            const data = await res.json();
            if (data.status === "OK") {
                return data.results[0]?.formatted_address || `${lat},${lng}`;
            } else {
                return `${lat}, ${lng}`;
            }
        } catch (e) {
            return `${lat}, ${lng}`;
        }
    }

    window.initMap = initMap;
</script>



    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async defer></script>
</body>
</html>
