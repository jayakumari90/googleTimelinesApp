<?php
// config.php
$host = 'localhost';
$db   = 'u995171350_anudanet';
$user = 'u995171350_anudanet';
$pass = '4bV>maOi5Yf#';

// Create mysqli connection
$mysqli = new mysqli($host, $user, $pass, $db);

// Check connection
if ($mysqli->connect_error) {
    die(json_encode(['error' => 'Database connection failed']));
}
?>
