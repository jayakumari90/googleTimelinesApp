<?php

class GoogleMapsUrlExtractor {

    public static function expandShortUrl($shortUrl) {
        $ch = curl_init($shortUrl);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $location = null;

        if (preg_match('/Location:\s*(.*?)\s/i', $response, $matches)) {
            $location = trim($matches[1]);
        }

        curl_close($ch);
        return $location;
    }

    public static function extractCoordinates($url) {
        // 1. Match ?q=LAT,LNG
        if (preg_match('/[?&]q=(-?\d+\.\d+),(-?\d+\.\d+)/', $url, $matches)) {
            return ['latitude' => (float)$matches[1], 'longitude' => (float)$matches[2]];
        }

        // 2. Match DMS format: 26°53'21.8"N 75°45'40.8"E
        if (preg_match('/(\d{1,3})°\s*(\d{1,2})\'\s*(\d{1,2}(?:\.\d+)?)"\s*([NS])[, ]+\s*(\d{1,3})°\s*(\d{1,2})\'\s*(\d{1,2}(?:\.\d+)?)"\s*([EW])/i', $url, $m)) {
            $lat = self::dmsToDecimal((int)$m[1], (int)$m[2], (float)$m[3], $m[4]);
            $lng = self::dmsToDecimal((int)$m[5], (int)$m[6], (float)$m[7], $m[8]);
            return ['latitude' => $lat, 'longitude' => $lng];
        }

        // 3. Match !3dLAT!4dLONG
        if (preg_match('/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/', $url, $matches)) {
            return ['latitude' => (float)$matches[1], 'longitude' => (float)$matches[2]];
        }

        // 4. Match /@LAT,LONG
        if (preg_match('/\/@(-?\d+\.\d+),(-?\d+\.\d+)/', $url, $matches)) {
            return ['latitude' => (float)$matches[1], 'longitude' => (float)$matches[2]];
        }

        return null;
    }

    private static function dmsToDecimal($degrees, $minutes, $seconds, $direction) {
        $decimal = $degrees + ($minutes / 60) + ($seconds / 3600);
        if (strtoupper($direction) === 'S' || strtoupper($direction) === 'W') {
            $decimal *= -1;
        }
        return $decimal;
    }

    public static function processGoogleMapsUrl($url) {
        if (strpos($url, 'goo.gl') !== false || strpos($url, 'maps.app.goo.gl') !== false) {
            $expanded = self::expandShortUrl($url);
            if ($expanded) {
                $url = $expanded;
            } else {
                echo "Failed to expand short URL\n";
                return null;
            }
        }

        //echo "Final URL: $url\n";
        return self::extractCoordinates($url);
    }
    
    public static function getAddressFromLatLng($lat, $lng) {
        $url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lng";
    
        $opts = [
            "http" => [
                "method" => "GET",
                "header" => "User-Agent: PHP-Reverse-Geocoder/1.0\r\n"
            ]
        ];
    
        $context = stream_context_create($opts);
        $response = file_get_contents($url, false, $context);
    
        if ($response !== false) {
            $data = json_decode($response, true);
            return $data['display_name'] ?? null;
        }
    
        return null;
    }

}
