<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

require_once(__DIR__ . '/config.php');

// Read JSON input
$input = json_decode(file_get_contents("php://input"), true);
$userIds = $input['user_id'] ?? [];

$entityTypeId = 1086;
$response = [];

foreach ($userIds as $userId) {
    $stmt = $mysqli->prepare("
        SELECT latitude, longitude, timestamp, visitor_stage 
        FROM locations 
        WHERE entityTypeId = ? AND user_id = ? 
        ORDER BY id DESC 
        LIMIT 1
    ");
    $stmt->bind_param("ii", $entityTypeId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    echo "<pre>";print_r($result->fetch_assoc());die;
    if ($row = $result->fetch_assoc()) {
        $latitudes = explode(',', $row['latitude']);
        $longitudes = explode(',', $row['longitude']);
        $timestamps = explode(',', $row['timestamp']);

        // Get last valid point (non-zero)
        $lastIndex = count($latitudes) - 1;
        for ($i = $lastIndex; $i >= 0; $i--) {
            $lat = isset($latitudes[$i]) ? trim($latitudes[$i]) : null;
            $lng = isset($longitudes[$i]) ? trim($longitudes[$i]) : null;

            if ($lat && $lng && (float)$lat > 0 && (float)$lng > 0) {
                $response[] = [
                    'user_id' => $userId,
                    // 'username' => getUserName($userId, $mysqli),
                    'lat' => (float)$lat,
                    'lng' => (float)$lng
                ];
                break;
            }
        }
    }

    $stmt->close();
}

// Return final list of user live locations
echo json_encode($response);
