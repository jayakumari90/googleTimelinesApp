<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

require_once(__DIR__ . '/config.php');
require_once(__DIR__ . '/../utils/stop_detector.php');
require_once(__DIR__ . '/../utils/filter_jumps.php');

$entityTypeId = 1086;
$date = $_GET['date'] ?? '';
$date = trim($date);
$isDateGiven = (!empty($date) && $date !== 'undefined');

$filterDate = $isDateGiven ? date('Y-m-d', strtotime($date)) : null;

$entries = [];

if (isset($_GET['user_id']) && !empty($_GET['user_id']) && $isDateGiven) {
    // Case 1: Fetch data by user_id and date
    $stmt = $mysqli->prepare("
        SELECT latitude, longitude, timestamp, visitor_stage, battery 
        FROM locations 
        WHERE entityTypeId = ? AND user_id = ? AND DATE(timestamp) = ?
        ORDER BY timestamp ASC
    ");
    $stmt->bind_param("iis", $entityTypeId, $_GET['user_id'], $filterDate);
} elseif (isset($_GET['visitor_id']) && !empty($_GET['visitor_id'])) {
    // Case 2: Fetch data by visitor_id (no date filter)
    $stmt = $mysqli->prepare("
        SELECT latitude, longitude, timestamp, visitor_stage, battery 
        FROM locations 
        WHERE entityTypeId = ? AND visitor_id = ?
    ");
    $stmt->bind_param("ii", $entityTypeId, $_GET['visitor_id']);
} else {
    echo json_encode(['error' => 'Missing or invalid parameters: user_id with date OR visitor_id is required.']);
    exit;
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $latitudes = explode(',', $row['latitude']);
    $longitudes = explode(',', $row['longitude']);
    $timestamps = explode(',', $row['timestamp']);
    $visitor_stage = (int)($row['visitor_stage'] ?? 0);
    $battery = explode(',', $row['battery']);

    $locations = [];
    $cleanTimestamps = [];
    $battery_per = [];

    $maxCount = max(count($latitudes), count($longitudes), count($timestamps));
    for ($i = 0; $i < $maxCount; $i++) {
        $lat = isset($latitudes[$i]) ? trim($latitudes[$i]) : null;
        $lng = isset($longitudes[$i]) ? trim($longitudes[$i]) : null;
        $time = isset($timestamps[$i]) ? trim($timestamps[$i]) : null;
        $battery = isset($battery[$i]) ? trim($battery[$i]) : 0;

        if (!$lat || !$lng || (float)$lat <= 0 || (float)$lng <= 0) continue;

        $locations[] = ['lat' => (float)$lat, 'lng' => (float)$lng, 'battery' => $battery];
        $cleanTimestamps[] = $time ?: '';
    }

    if (count($locations) === 0) continue;

    // Detect significant stops
   $stops = detectSignificantStops($locations, $cleanTimestamps);

    $entries[] = [
        'locations' => $locations,
        'timestamps' => $cleanTimestamps,
        'battery' => $battery_per,
        'stage' => $visitor_stage,
        'stops' => $stops
    ];
}

$stmt->close();

echo json_encode(['entries' => $entries]);
