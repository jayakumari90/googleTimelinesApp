<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
set_time_limit(20); // prevent long execution hanging

header('Content-Type: application/json');

require_once(__DIR__ . '/config.php');
require_once(__DIR__ . '/bitrix_api.php');
require_once(__DIR__ . '/../utils/stop_detector.php');
require_once(__DIR__ . '/../utils/filter_jumps.php');
require_once(__DIR__ . '/GoogleMapsUrlExtractor.php');

$entityTypeId = 1086;
$date = $_GET['date'] ?? '';
$date = trim($date);
$isDateGiven = (!empty($date) && $date !== 'undefined');
$filterDate = $isDateGiven ? date('Y-m-d', strtotime($date)) : null;

$entries = [];

if (isset($_GET['user_id']) && is_array($_GET['user_id']) && $isDateGiven) {
    $userIds = $_GET['user_id'];

    // $geoCache = []; // ✅ in-memory cache to avoid repeated API calls

    // function getCachedAddress($lat, $lng) {
    //     global $geoCache;
    //     $key = "$lat,$lng";
    //     if (!isset($geoCache[$key])) {
    //         $geoCache[$key] = GoogleMapsUrlExtractor::getAddressFromLatLng($lat, $lng);
    //     }
    //     return $geoCache[$key];
    // }

    foreach ($userIds as $uid) {
        $stmt = $mysqli->prepare("
            SELECT latitude, longitude, timestamp, visitor_stage, battery 
            FROM locations 
            WHERE entityTypeId = ? AND user_id = ? AND DATE(timestamp) = ?
            ORDER BY timestamp ASC
        ");
        $stmt->bind_param("iis", $entityTypeId, $uid, $filterDate);
        $stmt->execute();
        $result = $stmt->get_result();

        $allLocations = [];
        $allTimestamps = [];
        $visitor_stage = 0;

        while ($row = $result->fetch_assoc()) {
            $latitudes = explode(',', $row['latitude']);
            $longitudes = explode(',', $row['longitude']);
            $timestamps = explode(',', $row['timestamp']);
            $batteryData = explode(',', $row['battery']);
            $visitor_stage = (int)($row['visitor_stage'] ?? 0);

            $maxCount = max(count($latitudes), count($longitudes), count($timestamps));

            for ($i = 0; $i < $maxCount; $i++) {
                $lat = trim($latitudes[$i] ?? '');
                $lng = trim($longitudes[$i] ?? '');
                $time = trim($timestamps[$i] ?? '');
                $battery = trim($batteryData[$i] ?? 0);

                if ((float)$lat > 0 && (float)$lng > 0) {
                    $allLocations[] = [
                        'lat' => (float)$lat,
                        'lng' => (float)$lng,
                        'battery' => $battery,
                        'geolocation' => ''//getCachedAddress((float)$lat, (float)$lng)
                    ];
                    $allTimestamps[] = $time;
                }
            }
        }

        $stmt->close();

        if (count($allLocations) > 0) {
            // 🚀 Optional: Limit total locations to latest 500
            if (count($allLocations) > 500) {
                $allLocations = array_slice($allLocations, -500);
                $allTimestamps = array_slice($allTimestamps, -500);
            }

            // 🔍 Get Bitrix user info
            $userResult = get_user_info($uid);
            $name = trim(($userResult['NAME'] ?? '') . ' ' . ($userResult['LAST_NAME'] ?? ''));
            $profile = $userResult['PERSONAL_PHOTO'] ?? 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';

            // 🕓 Detect stops
            $stops = detectSignificantStops($allLocations, $allTimestamps);

            // 🎯 Final result for one user
            $entries[] = [
                'user_id' => $uid,
                'name' => $name,
                'profile' => $profile,
                'locations' => $allLocations,
                'timestamps' => $allTimestamps,
                'stage' => $visitor_stage,
                'stops' => $stops
            ];
        }
    }

    echo json_encode(['entries' => $entries]);
    exit;
} else {
    echo json_encode(['error' => 'Missing or invalid parameters: user_id[] with date OR visitor_id is required.']);
    exit;
}
