<?php
require_once(__DIR__ . '/config.php');
require_once(__DIR__ . '/bitrix_api.php');

$recordId = $_POST['id'] ?? null;
$entityTypeId = 1086;

if (!$recordId) {
    die("Missing visitor ID");
}

// Step 1: Get user_id from DB
$stmt = $mysqli->prepare("SELECT user_id FROM locations WHERE entityTypeId = ? AND visitor_id = ?");
$stmt->bind_param("ii", $entityTypeId, $recordId);
$stmt->execute();
$stmt->bind_result($user_id);

if (!$stmt->fetch()) {
    die("User ID not found for visitor_id = $recordId");
}
$stmt->close();

// Step 2: Get Bitrix user info
$userInfo = get_user_info($user_id);
if (!$userInfo) {
    die("Bitrix user not found");
}
// echo '<pre>';print_r($userInfo);
// Step 3: Extract department ID from user info
$departmentId = $userInfo['UF_DEPARTMENT'][0] ?? [];


if (empty($departmentId)) {
    die("User has no department assigned");
}
if ($departmentId && is_user_supervisor($user_id, $departmentId)) {
    // Step 4: Get all users in the department
    $departmentUsers = get_department_users($departmentId);
    $optionHtml = '<option value="">All</option>';

    foreach ($departmentUsers as $emp) {
        $empId = htmlspecialchars($emp['ID']);
        $empName = htmlspecialchars($emp['NAME'] . ' ' . $emp['LAST_NAME']);
        $optionHtml .= '<option value="' . $empId . '">' . $empName . '</option>';
    }
} else {
    $optionHtml = '<option value="' . $user_id . '">' . $userInfo['NAME'] . ' ' . $userInfo['LAST_NAME'].'</option>';
}
echo json_encode(['success' => true, 'data' => $optionHtml, 'username'=>$userInfo['NAME'] . ' ' . $userInfo['LAST_NAME'], 'userid' => $user_id]);
exit;

