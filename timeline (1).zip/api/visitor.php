<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

require_once(__DIR__ . '/config.php');
require_once(__DIR__ . '/../utils/stop_detector.php');
require_once(__DIR__ . '/../utils/filter_jumps.php');

$entityTypeId = 1086;
$date = $_GET['date'] ?? '';
$date = trim($date);
$isDateGiven = (!empty($date) && $date !== 'undefined');
$locations = [];
$timestamps = [];

$filterDate = $isDateGiven ? date('Y-m-d', strtotime($date)) : null;

if (isset($_GET['visitor_id']) && !empty($_GET['visitor_id'])) {
    $stmt = $mysqli->prepare("
        SELECT latitude, longitude, timestamp, visitor_stage 
        FROM locations 
        WHERE entityTypeId = ? AND visitor_id = ? AND DATE(timestamp) = ?
        ORDER BY timestamp ASC
    ");
    $stmt->bind_param("iis", $entityTypeId, $_GET['visitor_id'], $filterDate);
} else {
    echo json_encode(['error' => 'Missing visitor_id']);
    exit;
}

$stmt->execute();
$result = $stmt->get_result();
$visitor_stage = 0;

while ($row = $result->fetch_assoc()) {
    $latitudes = explode(',', $row['latitude']);
    $longitudes = explode(',', $row['longitude']);
    $times = explode(',', $row['timestamp']);
    $visitor_stage = (int)($row['visitor_stage'] ?? 0);

    $maxCount = max(count($latitudes), count($longitudes), count($times));
    for ($i = 0; $i < $maxCount; $i++) {
        $lat = isset($latitudes[$i]) ? trim($latitudes[$i]) : null;
        $lng = isset($longitudes[$i]) ? trim($longitudes[$i]) : null;
        $time = isset($times[$i]) ? trim($times[$i]) : null;

        if (!$lat || !$lng || (float)$lat <= 0 || (float)$lng <= 0) continue;

        $locations[] = ['lat' => (float)$lat, 'lng' => (float)$lng];
        $timestamps[] = $time ?: date('Y-m-d H:i:s');
    }
}

$stmt->close();

// Optional: Filter unrealistic GPS jumps (over 1000m)
$rawLocations = array_map(function ($loc, $ts) {
    return ['lat' => $loc['lat'], 'lng' => $loc['lng'], 'timestamp' => $ts];
}, $locations, $timestamps);

$filtered = filterGpsJumps($rawLocations, 1000);
$filteredLocations = $filtered;
$timestampsFiltered = array_column($filtered, 'timestamp');

// Detect stops longer than 5 minutes
$stops = detectSignificantStops($filteredLocations, $timestampsFiltered, 5, 30);

// Final response
$response = [
    'locations' => array_map(function ($loc) {
        return ['lat' => $loc['lat'], 'lng' => $loc['lng']];
    }, $filteredLocations),
    'timestamps' => $timestampsFiltered,
    'count' => count($filteredLocations),
    'stops' => $stops,
    'stage' => $visitor_stage
];

echo json_encode($response);
