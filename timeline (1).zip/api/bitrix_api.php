<?php
// bitrix_api.php content
$bitrix_webhook = 'https://myanuda.com/rest/7033/j4wjq3aamwbaa959/';

// Get user info
// Get Bitrix user info
function get_user_info($userId = null) {
    global $bitrix_webhook;
    $url = $bitrix_webhook . "user.get.json?ID[]=" . $userId;
    $response = file_get_contents($url);
    return json_decode($response, true)['result'][0] ?? null;
}

// Recursively get all child department IDs
function get_child_departments($departments, $parentId) {
    $childs = [];
    foreach ($departments as $dept) {
        if ((string)($dept['PARENT'] ?? '') === (string)$parentId) {
            $childs[] = $dept['ID'];
            // Recursive call for this child
            $childs = array_merge($childs, get_child_departments($departments, $dept['ID']));
        }
    }
    return $childs;
}

// Fetch all departments (with pagination)
function get_all_departments() {
    $all = [];
    $start = 0;

    do {
        $url = "https://myanuda.com/rest/7033/zebrsup13ae2abq6/department.get.json?start=" . $start;
        $response = json_decode(file_get_contents($url), true);
        $result = $response['result'] ?? [];
        $all = array_merge($all, $result);
        $start = $response['next'] ?? null;
    } while ($start !== null);

    return $all;
}

// Get all users in a department
function get_department_users($departmentId) {
    global $bitrix_webhook;
    $url = $bitrix_webhook . "user.get.json?FILTER[UF_DEPARTMENT][]=" . $departmentId . "&FILTER[ACTIVE]=1";
    $response = file_get_contents($url);
    return json_decode($response, true)['result'] ?? [];
}

// Get all users across multiple department IDs
function get_multiple_department_users($departmentIds) {
    global $bitrix_webhook;
    $query = [
        'FILTER' => [
            'UF_DEPARTMENT' => $departmentIds,
            'ACTIVE' => 1
        ]
    ];
    $url = $bitrix_webhook . "user.get.json?" . http_build_query($query);
    $response = file_get_contents($url);
    return json_decode($response, true)['result'] ?? [];
}
function collect_all_child_departments($departments, $parentId, &$result) {
        foreach ($departments as $dept) {
            if (isset($dept['PARENT']) && $dept['PARENT'] == $parentId) {
                $result[] = $dept['ID'];
                collect_all_child_departments($departments, $dept['ID'], $result);
            }
        }
    }
// Check if a user is a supervisor of a department (kept for potential future use)
function is_user_supervisor($userId, $departmentId) {
    global $bitrix_webhook;
    $url = "https://myanuda.com/rest/7033/zebrsup13ae2abq6/department.get.json?ID[]=" . $departmentId;
    $response = file_get_contents($url);
    $result = json_decode($response, true);
    if (!isset($result['result'][0]['UF_HEAD'])) {
        return false;
    }
    $departmentHeadId = $result['result'][0]['UF_HEAD'];
    return ($departmentHeadId == $userId);
}

function getAssignedDeals($assignedUserId, $catID) {
    $baseUrl = 'https://myanuda.com/rest/1/os0qynniykwfrrqh';
    $url = "$baseUrl/crm.deal.list.json?filter[ASSIGNED_BY_ID]=$assignedUserId&filter[CATEGORY_ID]=$catID";

    $payload = json_encode([
        "select" => [
            "ID",
            "TITLE",
            "STAGE_ID",
            "DATE_CREATE",
            "UF_CRM_1717400893721"
        ]
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['status' => 'error', 'message' => $error];
    }

    if ($httpCode !== 200) {
        return ['status' => 'error', 'message' => "HTTP $httpCode", 'response' => $response];
    }

    $result = json_decode($response, true);
    return $result['result'] ?? ['status' => 'error', 'message' => 'Invalid response format'];
}

function filterInProgressDeals($deals) {
    return array_filter($deals, function ($deal) {
        $stage = strtoupper($deal['STAGE_ID']);

        // Remove plain WON/LOSE or any STAGE_ID ending in :WON or :LOSE
        return !in_array($stage, ['WON', 'LOSE']) &&
               !preg_match('/:WON$/', $stage) &&
               !preg_match('/:LOSE$/', $stage);
    });
}

function filterWonDeals($deals) {
    return array_filter($deals, function ($deal) {
        $stage = strtoupper($deal['STAGE_ID']);

        // Remove plain WON/LOSE or any STAGE_ID ending in :WON or :LOSE
        return in_array($stage, ['C17:WON']);
    });
}


