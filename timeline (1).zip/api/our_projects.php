<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
require_once(__DIR__ . '/config.php');
require_once(__DIR__ . '/bitrix_api.php');
require 'GoogleMapsUrlExtractor.php';
/********************Get Userid Start*************************/
$entityTypeId = 1086;
if (isset($_GET['visitor_id']) && !empty($_GET['visitor_id'])) {
    // Case 2: Fetch data by visitor_id (no date filter)
    $stmt = $mysqli->prepare("
        SELECT user_id
        FROM locations 
        WHERE entityTypeId = ? AND visitor_id = ?
    ");
    $stmt->bind_param("ii", $entityTypeId, $_GET['visitor_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    // Store userr_id from the result
    if ($row = $result->fetch_assoc()) {
        $userId = $row['user_id'];
        // Now you can use $userId
    } 
    $stmt->close();
}else{
    $userId = $_GET['assigned_id'];
}
/********************Get Userid End*************************/

/********************Branches Start*************************/
$query = "SELECT id, branch_name, branch_address, lat, lng, image, geolocation,  status FROM branches";
$result = $mysqli->query($query);

if (!$result) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Query failed: ' . $mysqli->error
    ]);
    exit;
}

// Fetch data
$branches = [];
while ($row = $result->fetch_assoc()) {
    
    $row['geolocation'] = GoogleMapsUrlExtractor::processGoogleMapsUrl($row['geolocation']);
    $branches[] = $row;
}
/********************Branches End*************************/


$deals = getAssignedDeals($userId, 17);


/********************Live Deals Start*************************/
$inProgressDeals = filterInProgressDeals($deals);
$livedeals = [];
foreach ($inProgressDeals as $deal) {
    $url = $deal['UF_CRM_1717400893721'] ?? '';
    // echo "Checking deal: {$deal['ID']} | URL: $url\n";

    $geo = GoogleMapsUrlExtractor::processGoogleMapsUrl($url);
     if ($geo && isset($geo['latitude']) && isset($geo['longitude'])) {
        $project_address =  GoogleMapsUrlExtractor::getAddressFromLatLng($geo['latitude'], $geo['longitude']);
        $livedeals[] = [
            'id' => $deal['ID'],
            'deal_name' => $deal['TITLE'] ?? 'Unnamed Deal',
            'deal_address' => $project_address ?? 'No location provided',
            'lat' => $geo['latitude'],
            'lng' => $geo['longitude'],
            'geolocation' => [
                'latitude' => $geo['latitude'],
                'longitude' => $geo['longitude']
            ],
            'status' => '1'
        ];
    }
}
/********************Live Deals End*************************/

/********************Won Deals Start*************************/
$wonDeals = filterWonDeals($deals);
$completeddeals = [];
foreach ($wonDeals as $deal) {
    $url = $deal['UF_CRM_1717400893721'] ?? '';
    // echo "Checking deal: {$deal['ID']} | URL: $url\n";

    $geo = GoogleMapsUrlExtractor::processGoogleMapsUrl($url);
     if ($geo && isset($geo['latitude']) && isset($geo['longitude'])) {
        $project_address =  GoogleMapsUrlExtractor::getAddressFromLatLng($geo['latitude'], $geo['longitude']);
        $completeddeals[] = [
            'id' => $deal['ID'],
            'deal_name' => $deal['TITLE'] ?? 'Unnamed Deal',
            'deal_address' => $project_address ?? 'No location provided',
            'lat' => $geo['latitude'],
            'lng' => $geo['longitude'],
            'geolocation' => [
                'latitude' => $geo['latitude'],
                'longitude' => $geo['longitude']
            ],
            'status' => '1'
        ];
    }
}
/********************Won Deals End*************************/

/********************Upcoming Deals Start*************************/
$deals = getAssignedDeals($userId, 0);
//$inProgressDeals = filterInProgressDeals($deals);
// echo '<pre>';print_r($inProgressDeals);die('hg');
$upcomingdeals = [];
foreach ($deals as $deal) {
    $url = $deal['UF_CRM_1717400893721'] ?? '';
    // echo "Checking deal: {$deal['ID']} | URL: $url\n";

    $geo = GoogleMapsUrlExtractor::processGoogleMapsUrl($url);
     if ($geo && isset($geo['latitude']) && isset($geo['longitude'])) {
        $project_address =  GoogleMapsUrlExtractor::getAddressFromLatLng($geo['latitude'], $geo['longitude']);
        $upcomingdeals[] = [
            'id' => $deal['ID'],
            'deal_name' => $deal['TITLE'] ?? 'Unnamed Deal',
            'deal_address' => $project_address ?? 'No location provided',
            'lat' => $geo['latitude'],
            'lng' => $geo['longitude'],
            'geolocation' => [
                'latitude' => $geo['latitude'],
                'longitude' => $geo['longitude']
            ],
            'status' => '1'
        ];
    }
}
/********************Upcoming Deals End*************************/
// Return JSON
echo json_encode([
    'status' => 'success',
    'count' => count($branches),
    'branches' => $branches,
    'livedeals'=>$livedeals,
    'upcomming'=>$upcomingdeals,
    'wondeals'=>$completeddeals,
    'deal_count'=> count($inProgressDeals)
]);

$mysqli->close();
