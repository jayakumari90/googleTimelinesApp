<?php
require_once(__DIR__ . '/config.php');
require_once(__DIR__ . '/bitrix_api.php');

// Step 0: Get the user ID from POST
$user_id = $_POST['id'] ?? null;
if (!$user_id) {
    die("Missing visitor ID");
}

// Step 1: Get Bitrix user info
$userInfo = get_user_info($user_id);
if (!$userInfo) {
    die("Bitrix user not found");
}

// Step 2: Extract user's departments
$departmentIds = $userInfo['UF_DEPARTMENT'] ?? [];

if (empty($departmentIds)) {
    die("No department assigned to user");
}

// Step 3: Get all departments (with pagination)
$allDepartments = get_all_departments();

$isSupervisor = false;
foreach ($allDepartments as $dept) {
    if (isset($dept['UF_HEAD']) && $dept['UF_HEAD'] == $user_id) {
        $isSupervisor = true;
        break;
    }
}

if ($isSupervisor) {
    // Supervisor: Collect all department IDs (own + sub-departments)
    $allDepartmentIds = [];
    foreach ($departmentIds as $deptId) {
        $childDepts = get_child_departments($allDepartments, $deptId);
        $allDepartmentIds = array_merge($allDepartmentIds, [$deptId], $childDepts);
    }
    $allDepartmentIds = array_values(array_unique($allDepartmentIds));

    // Fetch users from all departments
    $allUsers = get_multiple_department_users($allDepartmentIds);
} else {
    // Not a supervisor: show only own info
    $allUsers = [$userInfo];
}

// // Step 4: Collect all department IDs (user's + children recursively)
// $allDepartmentIds = [];
// foreach ($departmentIds as $deptId) {
//     $childDepts = get_child_departments($allDepartments, $deptId);
//     $allDepartmentIds = array_merge($allDepartmentIds, [$deptId], $childDepts);
// }
// $allDepartmentIds = array_values(array_unique($allDepartmentIds));

// // Output result for testing
// // echo "<pre>";
// // print_r($allDepartmentIds);
// // echo "</pre>";
// // die;

// // Step 5: Fetch users from all relevant departments
// $allUsers = [];
// // ✅ Step 5: Get all users in a single API call for all departments
// $allUsers = get_multiple_department_users($allDepartmentIds);
// foreach ($allDepartmentIds as $deptId) {
//     echo  "deptid=".$deptId;
//     $users = get_department_users($deptId);
//     $allUsers = array_merge($allUsers, $users);
//      // ✅ This prints fine inside the loop
// }
// Step 6: Remove duplicates (by user ID)
$uniqueUsers = [];
$optionHtml = '';
foreach ($allUsers as $user) {
    $uniqueUsers[$user['ID']] = $user;
}
foreach ($uniqueUsers as $user) {
    $optionHtml .= '<option value="' . $user['ID'] . '">' . $user['NAME'] . ' ' . $user['LAST_NAME'] . '</option>';
}
echo json_encode(['success' => true, 'data' => $optionHtml, 'username'=>$userInfo['NAME'] . ' ' . $userInfo['LAST_NAME'], 'userid' => $user_id]);
exit;
