let map, marker = null;
let animationInterval = null;
const polylineRefs = [];
const markerRefs = [];
const colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown', 'teal', 'darkblue', 'maroon'];
function initMap() {
    map = L.map('map').setView([21.218, 74.833], 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
}

function clearMap() {
    polylineRefs.forEach(line => map.removeLayer(line));
    markerRefs.forEach(m => map.removeLayer(m));
    polylineRefs.length = 0;
    markerRefs.length = 0;
    if (animationInterval) clearInterval(animationInterval);
    if (marker) {
        map.removeLayer(marker);
        marker = null;
    }
}

function drawPolyline(coords, color = 'blue') {
    const polyline = L.polyline(coords, { color }).addTo(map);
    polylineRefs.push(polyline);
    return polyline;
}

function createColoredMarker(position, color = 'blue') {
    const icon = L.icon({
        iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
        shadowSize: [41, 41]
    });
    const m = L.marker(position, { icon }).addTo(map);
    markerRefs.push(m);
    return m;
}

function startLiveTracking(points, color = 'blue') {
    if (!points || points.length === 0) return;

    let index = 0;

    // Create colored icon
    const icon = L.icon({
        iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
        shadowSize: [41, 41]
    });

    if (marker) map.removeLayer(marker);
    marker = L.marker(points[0], { icon }).addTo(map);

    animationInterval = setInterval(() => {
        index++;
        if (index >= points.length) {
            clearInterval(animationInterval);
            return;
        }
        marker.setLatLng(points[index]);
    }, 10000);
}

    

function stopUserTracking() {
    if (userPollingInterval) {
        clearInterval(userPollingInterval);
        userPollingInterval = null;
        console.log("🛑 User live tracking stopped.");
    }
}

function formatTime12Hour(datetime) {
    const date = new Date(datetime);
    return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

function calculateDuration(from, to) {
    const fromTime = new Date(from);
    const toTime = new Date(to);
    const diffMs = toTime - fromTime;
    const diffMins = Math.floor(diffMs / 60000); // total minutes

    const hours = Math.floor(diffMins / 60);
    const minutes = diffMins % 60;

    if (hours > 0) {
        return `${hours} hr${hours > 1 ? 's' : ''} ${minutes} min`;
    } else {
        return `${minutes} min`;
    }
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of Earth in KM

    // Round to 5 decimal places to avoid noise in GPS drift
    lat1 = +lat1.toFixed(5);
    lon1 = +lon1.toFixed(5);
    lat2 = +lat2.toFixed(5);
    lon2 = +lon2.toFixed(5);

    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    const distance = R * c;
    return distance < 0.05 ? 0 : distance; // Ignore distances < 50m as noise
}

// Format a location block like "THE RING RESIDENCY..." etc.
function renderStartLocation(stop, label = "Start Location") {
    const time = formatTime12Hour(stop.from);
    return `
        <div class="stop-entry" data-lat="${stop.lat}" data-lng="${stop.lng}" style="cursor:pointer;">
            <div class="stop-marker">📍</div>
            <strong>${label}</strong><br>
            Left at ${time}<br>
        </div>`;
}

// Format a driving block like "Driving\n17km · 54 min\n8:59 am – 9:53 am"
function renderDrivingBlock(from, to, fromCoord, toCoord, battery) {
    const distance = calculateDistance(fromCoord.lat, fromCoord.lng, toCoord.lat, toCoord.lng).toFixed(2);
    const duration = calculateDuration(from, to);
    const fromTime = formatTime12Hour(from);
    const toTime = formatTime12Hour(to);
    console.log('toCoord', toCoord);
    return `
        <div class="stop-entry" data-lat="${toCoord.lat}" data-lng="${toCoord.lng}" style="cursor:pointer;">
            <div class="stop-marker">🚗</div>
            <strong>Driving</strong><br>
            ${distance} km · ${duration}<br>
            ${fromTime} – ${toTime}<br>
            ${battery}<br>
            <span>Duration: ${duration} </span><br>
        </div>`;
}

// Format a stop like "Visited Anuda?\n9:53 am – 2:14 pm"
function renderStopBlock(stop, label = "") {
    const fromTime = formatTime12Hour(stop.from);
    const toTime = formatTime12Hour(stop.to);
    const duration = calculateDuration(stop.from, stop.to);

    return `
        <div class="stop-entry" data-lat="${stop.lat}" data-lng="${stop.lng}" style="cursor:pointer;">
            <div class="stop-marker">📍</div>
            <strong>${label || `Visited?`}</strong><br>
            ${fromTime} – ${toTime}<br>
            ${stop.battery}<br>
            <span>Duration: ${duration} </span><br>
        </div>`;
}


function formatTotalDuration(mins) {
    const hrs = Math.floor(mins / 60);
    const rem = mins % 60;
    return hrs > 0 ? `${hrs} hr${hrs > 1 ? 's' : ''} ${rem} min` : `${rem} min`;
}


function displayMultipleEntries(entries) {
    clearMap();
    if (!entries || entries.length === 0) return;

    let liveTracked = false;
    const timelineContainer = document.querySelector('.timeline-detail');
    timelineContainer.innerHTML = ''; // Clear timeline
    console.log('entries.timestemps[0]', entries[0].timestamps[0])
    let visitCount = 0;
    let totalKm = 0;
    let totalDurationMin = 0;
    const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
    const formatted = new Date(entries[0].timestamps[0]).toLocaleDateString('en-GB', options);
    document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');
    entries.forEach((entry, idx) => {
        const coords = entry.locations.map(p => [p.lat, p.lng]);
        const color = colors[idx % colors.length];

        const poly = drawPolyline(coords, color);
        const lastCoord = coords[coords.length - 1];

        // 🟢 Live tracking (only once, for first entry with stage == 1)
        if (entry.stage == 1 && !liveTracked) {
            // Timeline Section
        // <div class="stop-marker">📍</div>
        timelineContainer.innerHTML += `<h4 style="color:${color};">Entry ${idx + 1}</h4>`;
        if (entry.stops && entry.stops.length > 0) {
            //entry.stops.forEach((stop, sIndex) => {
                // timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">🚗</div>
                        
                //         <strong>Stop ${sIndex + 1}</strong><br>
                //         From: ${stop.from}<br>
                //         To: ${stop.to}<br>
                //         <span>Duration: ${stop.duration_min} mins</span><br>
                        
                //     </div>`;
                // if (sIndex > 0) {
                //     const prev = entry.stops[sIndex - 1];
                //     console.log('prev==', prev)
                //     const distance = calculateDistance(prev.lat, prev.lng, stop.lat, stop.lng);
                //     const fromTime = formatTime12Hour(prev.to);
                //     const toTime = formatTime12Hour(stop.from);
                //     const duration = calculateDuration(prev.to, stop.from);
                //     timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">🚗</div>

                        
                        
                //         <strong>Driving</strong><br>
                //         ${fromTime} – ${toTime}<br>
                //         Distance: ${distance.toFixed(2)} km
                //         <span>Duration: ${duration} </span><br>
                        
                //     </div>`;
                // }
                // const fromTime = formatTime12Hour(stop.from);
                // const toTime = formatTime12Hour(stop.to);
                // const duration = calculateDuration(stop.from, stop.to);
                // timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">📍</div>

                        
                        
                //         <strong>Stop ${sIndex + 1}</strong><br>
                //         ${fromTime} - ${toTime}<br>
                //         <span>Duration: ${duration} </span><br>
                        
                //     </div>`;
                const stops = entry.stops;
                timelineContainer.innerHTML += renderStartLocation(stops[0], "Start Point");

                for (let sIndex = 1; sIndex < stops.length; sIndex++) {
                    const prev = stops[sIndex - 1];
                    const curr = stops[sIndex];
                    const durationMin = Math.floor((new Date(curr.to) - new Date(curr.from)) / 60000);
                    totalDurationMin += durationMin;
                    const segmentKm = calculateDistance(prev.lat, prev.lng, curr.lat, curr.lng);
                    totalKm += segmentKm;
                    visitCount++;
            
                    // Driving block between stops
                    timelineContainer.innerHTML += renderDrivingBlock(prev.to, curr.from, prev, curr, curr.battery);
            
                    // Stop block
                    timelineContainer.innerHTML += renderStopBlock(curr, `Stop ${sIndex}`);
                }
            //});
            // Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
            
            document.querySelectorAll('.stop-entry').forEach(entry => {
                console.log('stop entry===', entry)
                entry.addEventListener('click', function () {
                    const lat = parseFloat(this.getAttribute('data-lat'));
                    const lng = parseFloat(this.getAttribute('data-lng'));
            
                    // Remove old marker if needed
                    if (marker) map.removeLayer(marker);
            
                    // Add new marker for clicked stop
                    marker = L.marker([lat, lng]).addTo(map).bindPopup("Selected Stop").openPopup();
                    map.setView([lat, lng], 17);
                });
            });
        } else {
            timelineContainer.innerHTML += `<div>No significant stops (3+ min)</div>`;
        }
            map.fitBounds(poly.getBounds());
            liveTracked = true;

            // Animate live marker
            startLiveTracking(coords, color); // Pass color for marker
        } else {
            // Static marker only
            // Timeline Section
        // <div class="stop-marker">📍</div>
        timelineContainer.innerHTML += `<h4 style="color:${color};">Entry ${idx + 1}</h4>`;
        if (entry.stops && entry.stops.length > 0) {
            //entry.stops.forEach((stop, sIndex) => {
                // timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">🚗</div>
                        
                //         <strong>Stop ${sIndex + 1}</strong><br>
                //         From: ${stop.from}<br>
                //         To: ${stop.to}<br>
                //         <span>Duration: ${stop.duration_min} mins</span><br>
                        
                //     </div>`;
                // if (sIndex > 0) {
                //     const prev = entry.stops[sIndex - 1];
                //     console.log('prev==', prev)
                //     const distance = calculateDistance(prev.lat, prev.lng, stop.lat, stop.lng);
                //     const fromTime = formatTime12Hour(prev.to);
                //     const toTime = formatTime12Hour(stop.from);
                //     const duration = calculateDuration(prev.to, stop.from);
                //     timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">🚗</div>

                        
                        
                //         <strong>Driving</strong><br>
                //         ${fromTime} – ${toTime}<br>
                //         Distance: ${distance.toFixed(2)} km
                //         <span>Duration: ${duration} </span><br>
                        
                //     </div>`;
                // }
                // const fromTime = formatTime12Hour(stop.from);
                // const toTime = formatTime12Hour(stop.to);
                // const duration = calculateDuration(stop.from, stop.to);
                // timelineContainer.innerHTML += `
                //      <div 
                //             class="stop-entry" 
                //             style="cursor:pointer;"
                //             data-lat="${parseFloat(stop.lat)}" 
                //             data-lng="${parseFloat(stop.lng)}"
                //         >
                //         <div class="stop-marker">📍</div>

                        
                        
                //         <strong>Stop ${sIndex + 1}</strong><br>
                //         ${fromTime} - ${toTime}<br>
                //         <span>Duration: ${duration} </span><br>
                        
                //     </div>`;
                const stops = entry.stops;
                timelineContainer.innerHTML += renderStartLocation(stops[0], "Start Point");

                for (let sIndex = 1; sIndex < stops.length; sIndex++) {
                    const prev = stops[sIndex - 1];
                    const curr = stops[sIndex];
                    const durationMin = Math.floor((new Date(curr.to) - new Date(curr.from)) / 60000);
                    totalDurationMin += durationMin;
                    const segmentKm = calculateDistance(prev.lat, prev.lng, curr.lat, curr.lng);
                    totalKm += segmentKm;
                    visitCount++;
            
                    // Driving block between stops
                    timelineContainer.innerHTML += renderDrivingBlock(prev.to, curr.from, prev, curr, curr.battery);
            
                    // Stop block
                    timelineContainer.innerHTML += renderStopBlock(curr, `Stop ${sIndex}`);
                }
            //});
            // Location: Lat ${parseFloat(stop.lat).toFixed(5)}, Lng ${parseFloat(stop.lng).toFixed(5)}
            
            document.querySelectorAll('.stop-entry').forEach(entry => {
                console.log('stop entry===', entry)
                entry.addEventListener('click', function () {
                    const lat = parseFloat(this.getAttribute('data-lat'));
                    const lng = parseFloat(this.getAttribute('data-lng'));
            
                    // Remove old marker if needed
                    if (marker) map.removeLayer(marker);
            
                    // Add new marker for clicked stop
                    marker = L.marker([lat, lng]).addTo(map).bindPopup("Selected Stop").openPopup();
                    map.setView([lat, lng], 17);
                });
            });
        } else {
            timelineContainer.innerHTML += `<div>No significant stops (3+ min)</div>`;
        }
            createColoredMarker(lastCoord, color);
        }

        
    });
    console.log('visitCount', visitCount);
    const totalDurationFormatted = formatTotalDuration(totalDurationMin);
    document.getElementById("totalVisits").innerHTML = `<strong>${visitCount}</strong> Visits<br>${totalDurationFormatted}`;
    document.getElementById("totalDistance").innerHTML = `<strong>${totalKm.toFixed(2)}</strong> km<br>${totalDurationFormatted}`;
}


// 👇 Example call
function fetchUserData(userId, selectedDate) {
    fetch(`/location/timeline/api/data.php?user_id=${userId}&date=${selectedDate}`)
        .then(res => res.json())
        .then(data => {
            if (data.entries && data.entries.length > 0) {
                displayMultipleEntries(data.entries);
            } else {
                clearMap();
                alert("No tracking data found.");
            }
        })
        .catch(err => {
            console.error("Error loading tracking data:", err);
            clearMap();
        });
}



    


function updateLocation() {
        const urlParams = new URLSearchParams(window.location.search);
        let recordId = '';
        let url = '';

        if (urlParams.get('visitor_id')) {
            recordId = urlParams.get('visitor_id');
            url = '/location/timeline/api/get_visitor_data.php';
        } else {
            recordId = urlParams.get('user_id');
            url = '/location/timeline/api/get_all_emp_data.php';
        }

        $.ajax({
            url: url,
            method: 'POST',
            data: { id: recordId },
            dataType: 'json',
            success: function (response) {
                console.log("Received JSON:", response);
                $('#user_id').html(response.data);
                const dropdown = document.getElementById('user_id');
                const userId =  response.userid;//urlParams.get('user_id');
                if (dropdown) {
                        // dropdown.val([userId]).trigger('change');
                    const optionToSelect = dropdown.querySelector(`option[value="${userId}"]`);
                    if (optionToSelect) {
                        optionToSelect.selected = true;
                    }
                }
                $('.id_set h2').text(response.username);
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
            }
        });
    }

function toggleCalendar() {
const inputDiv = document.getElementById("calendarInput");
inputDiv.style.display = inputDiv.style.display === "block" ? "none" : "block";
$('.calendar-icon').css('display', 'none');
}

function updateDate() {
        const dateValue = document.getElementById("datePicker").value;
        if (dateValue) {
            const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
            const formatted = new Date(dateValue).toLocaleDateString('en-GB', options);
            document.getElementById("selectedDate").textContent = formatted.replace(/ /g, ' ');

            // 🔁 Refetch data for all selected users
            const urlParams = new URLSearchParams(window.location.search);
            const visitorId = urlParams.get('visitor_id');
            const userId = urlParams.get('user_id');
            console.log('visitorId', visitorId, 'userId', userId)

            if (visitorId) {
                fetchVisitorData(visitorId, dateValue); // ✅ Load only if visitor_id is present
            }else{
                const selected = $('#user_id').val();
                if(selected == null){
                    console.log('userId ', userId);
                    console.log('dateValue ', dateValue);
                    fetchUserData(userId, dateValue)
                }else{
                    console.log('userrrrr ', selected);
                    console.log('dateValue ', dateValue);
                    fetchUserData(selected, dateValue)
                }
                
            }
        }
    }
    
let visitorPollingInterval = null;    

function stopVisitorTracking() {
    if (visitorPollingInterval) {
        clearInterval(visitorPollingInterval);
        visitorPollingInterval = null;
        console.log("🔁 Live tracking stopped.");
    }
}
    
function drawVisitorRoute(coords, color = 'blue') {
    polyline = L.polyline(coords, { color }).addTo(map);
    map.fitBounds(polyline.getBounds());
}


function fetchVisitorData(visitorId, selectedDate) {
    fetch(`/location/timeline/api/data.php?visitor_id=${visitorId}&date=${selectedDate}`)
        .then(res => res.json())
            .then(data => {
                if (data.entries && data.entries.length > 0) {
                    displayMultipleEntries(data.entries);
                } else {
                    clearMap();
                    alert("No tracking data found.");
                }
            })
            .catch(err => {
                console.error("Error loading tracking data:", err);
                clearMap();
            });
        
    
}

let cachedProjects = {
  branches: [],
  upcomming: [],
  livedeals: [],
  wondeals: []
};

function getAllProjects(userId, visitorId){
    $.ajax({
        url: '/location/timeline/api/our_projects.php',
        method: 'GET',
        data: { assigned_id: userId, visitor_id: visitorId },
        success: function(response) {
            console.log("Full project response:", response);

            if (response.status === 'success') {
                cachedProjects = {
                  branches: response.branches || [],
                  livedeals: response.livedeals || [],
                  upcomming: response.upcomming || [],
                  wondeals: response.wondeals || []
                };
        
                renderSelectedProjects();
                const branches = response.branches;
                if (Array.isArray(branches)) {
                    branches.forEach((b, i) => {
                        console.log(`Branch ${i + 1}:`, b);
                    });
                    plotBranchLocations(branches); // ✅ Add project markers to map
                } else {
                    console.warn("branches is not an array:", branches);
                }
                const livedeals = response.livedeals;
                if (Array.isArray(livedeals)) {
                    livedeals.forEach((b, i) => {
                        console.log(`livedeals ${i + 1}:`, b);
                    });
                    plotProjectLocations(livedeals); // ✅ Add project markers to map
                } else {
                    console.warn("livedeals is not an array:", livedeals);
                }
                const upcomming = response.upcomming;
                if (Array.isArray(upcomming)) {
                    upcomming.forEach((b, i) => {
                        console.log(`upcomming ${i + 1}:`, b);
                    });
                    plotUpcommingLocations(upcomming); // ✅ Add project markers to map
                } else {
                    console.warn("upcomming is not an array:", livedeals);
                }
                const wondeals = response.wondeals;
                if (Array.isArray(wondeals)) {
                    wondeals.forEach((b, i) => {
                        console.log(`wondeals ${i + 1}:`, b);
                    });
                    plotCompletedLocations(wondeals); // ✅ Add project markers to map
                } else {
                    console.warn("wondeals is not an array:", wondeals);
                }
            } else {
                alert("Error: " + response.message);
            }
        },
        error: function(err) {
            console.error("AJAX error", err);
        }
    });
}


function plotBranchLocations(branches) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/anuda.png',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -30]
    });

    const bounds = L.latLngBounds([]);

    branches.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.branch_name || "Project"}</strong><br>
                    ${project.branch_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}



function plotProjectLocations(projects) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/live_projects.png',
        iconSize: [40, 40],
        iconAnchor: [25, 40],
        popupAnchor: [0, -40]
    });

    const bounds = L.latLngBounds([]);
    console.log('projects', projects)
    projects.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.deal_name || "Project"}</strong><br>
                    ${project.deal_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}

function plotUpcommingLocations(projects) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/comming_soon-removebg-preview.png',
        iconSize: [40, 40],
        iconAnchor: [25, 40],
        popupAnchor: [0, -40]
    });

    const bounds = L.latLngBounds([]);
    console.log('projects', projects)
    projects.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.deal_name || "Project"}</strong><br>
                    ${project.deal_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}

function plotCompletedLocations(projects) {
    if (!map) {
        console.error("Map not initialized yet.");
        return;
    }

    const projectIcon = L.icon({
        iconUrl: 'https://anuda.net/location/timeline/img/won.png',
        iconSize: [40, 40],
        iconAnchor: [25, 40],
        popupAnchor: [0, -40]
    });

    const bounds = L.latLngBounds([]);
    console.log('projects', projects)
    projects.forEach((project, i) => {
        // 🔁 Use geolocation first, fallback to lat/lng
        const lat = parseFloat(project.geolocation?.latitude || project.lat);
        const lng = parseFloat(project.geolocation?.longitude || project.lng);

        if (!isNaN(lat) && !isNaN(lng)) {
            const position = [lat, lng];

            const popupContent = `
                <div style="max-width: 250px;">
                    <strong>${project.deal_name || "Project"}</strong><br>
                    ${project.deal_address || ''}
                </div>
            `;

            const marker = L.marker(position, { icon: projectIcon })
                .addTo(map)
                .bindPopup(popupContent);

            markerRefs.push(marker);
            bounds.extend(position);
        } else {
            console.warn(`❌ Invalid coordinates for branch ${project.branch_name}`);
        }
    });

    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}


document.addEventListener('DOMContentLoaded', function () {
    // Ensure topbar stays visible
    const topbar = document.querySelector('.topbar');
    if (topbar) {
        topbar.style.zIndex = '10000';
        topbar.style.display = 'flex';
        topbar.style.position = 'fixed';
        topbar.style.top = '0';
        topbar.style.left = '0';
        topbar.style.width = '100%';
    }

    // Re-show topbar on any marker click
    const markerIcons = document.querySelectorAll('.leaflet-marker-icon');

    markerIcons.forEach(marker => {
        marker.addEventListener('click', function (e) {
            e.stopPropagation();
            if (topbar) {
                topbar.style.display = 'flex';
            }
        });
    });

    // Optional: Also listen for map clicks and keep topbar visible
    if (typeof map !== 'undefined') {
        map.on('click', function () {
            if (topbar) {
                topbar.style.display = 'flex';
            }
        });
    }
});

function renderSelectedProjects() {
  clearAllMarkers(); // ✅ Optional: remove previous ones

  const selected = $('#project_status').val(); // array

  if (selected.includes('branch')) {
    plotBranchLocations(cachedProjects.branches);
  }
  if (selected.includes('inprogress')) {
    plotProjectLocations(cachedProjects.livedeals);
  }
  if (selected.includes('upcomming')) {
    plotUpcommingLocations(cachedProjects.upcomming);
  }
  if (selected.includes('completed')) {
    plotCompletedLocations(cachedProjects.wondeals);
  }
}
// const markerRefs = [];
function clearAllMarkers() {
  if (Array.isArray(markerRefs)) {
    markerRefs.forEach(marker => map.removeLayer(marker));
    markerRefs.length = 0; // ✅ Clears array without reassigning
  }
}


function formatOption(option) {
  if (!option.id) return option.text;
  const image = $(option.element).data('image');
  return image ? $(`<span><img src="${image}" style="height:20px; margin-right:6px;" /> ${option.text}</span>`) : option.text;
}

    
$(document).ready(function () {
    $('#project_status').select2({
        placeholder: "Select Project/Branch",
        templateResult: formatOption,
        templateSelection: formatOption,
        width: '100%'
    });
    $('#project_status').on('change', function () {
      renderSelectedProjects();
    });
    $('.calendar-icon').css('display', 'block');
    $('#calendarInput').css('display', 'none');
    $('#user_id').select2({
        placeholder: "Select one or more users"
    });

    initMap();
    updateLocation();

    const urlParams = new URLSearchParams(window.location.search);
    const visitorId = urlParams.get('visitor_id');
    const userId = urlParams.get('user_id');
    const today = new Date().toISOString().split('T')[0];
    if (visitorId) {
        fetchVisitorData(visitorId, today); // ✅ Load only if visitor_id is present
        getAllProjects('',visitorId)
    }

    if (userId) {
        fetchUserData(userId, today)
        getAllProjects(userId,'')
        
    }
    
    window.onbeforeunload = () => stopLiveTracking();
});

$(document).ready(function() {
    $('#user_id').on('change', function() {
        clearMap();
        const today = new Date().toISOString().split('T')[0];
        $('.id_set h2').text($(this).find('option:selected').text());
        const selected = Array.from(this.selectedOptions).map(opt => opt.value);
        selected.forEach(userId => fetchUserData(userId, today));
    });
    
    
    
    $('.refresh').on('click', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const visitorId = urlParams.get('visitor_id');
        const userId = urlParams.get('user_id');
        const selectedDate = new Date().toISOString().split('T')[0];

        if (!visitorId) {
            fetchUserData(userId, selectedDate);
        }

        fetchVisitorData(visitorId, selectedDate); // Refresh map data
    })
});


    