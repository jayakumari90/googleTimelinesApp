<?php
function detectSignificantStops($locations, $timestamps, $minStopMinutes = 3, $radiusMeters = 30)
{
    $stops = [];
    $startIdx = 0;

    for ($i = 1; $i < count($locations); $i++) {
        $distance = haversineDistance(
            $locations[$startIdx]['lat'], $locations[$startIdx]['lng'],
            $locations[$i]['lat'], $locations[$i]['lng']
        );

        $startTime = strtotime($timestamps[$startIdx]);
        $endTime = strtotime($timestamps[$i]);
        $duration = ($endTime - $startTime) / 60; // in minutes

        if ($distance > $radiusMeters) {
            if ($duration >= $minStopMinutes) {
                $stops[] = [
                    'from' => $timestamps[$startIdx],
                    'to' => $timestamps[$i],
                    'duration_min' => round($duration),
                    'lat' => $locations[$startIdx]['lat'],
                    'lng' => $locations[$startIdx]['lng'],
                    'battery' => $locations[$startIdx]['battery']
                ];
            }
            $startIdx = $i;
        }
    }

    return $stops;
}
