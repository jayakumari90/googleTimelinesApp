<?php
require_once(__DIR__ . '/geo_utils.php');


function filterJumpyCoordinates($locations, $timestamps, $maxSpeedKmph = 150) {
    if (count($locations) < 2) return ['locations' => $locations, 'timestamps' => $timestamps];

    $filteredLocations = [$locations[0]];
    $filteredTimestamps = [$timestamps[0]];

    for ($i = 1; $i < count($locations); $i++) {
        $prev = $locations[$i - 1];
        $curr = $locations[$i];
        $timeDiff = strtotime($timestamps[$i]) - strtotime($timestamps[$i - 1]);
        if ($timeDiff <= 0) continue;

        $distance = haversine($prev['lat'], $prev['lng'], $curr['lat'], $curr['lng']);
        $speed = ($distance / ($timeDiff / 3600)); // in km/h

        if ($speed <= $maxSpeedKmph) {
            $filteredLocations[] = $curr;
            $filteredTimestamps[] = $timestamps[$i];
        }
    }

    return ['locations' => $filteredLocations, 'timestamps' => $filteredTimestamps];
}
