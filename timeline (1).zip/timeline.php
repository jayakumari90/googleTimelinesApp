<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Dashboard Clone</title>
    <link rel="icon" href="img/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="/location/timeline/css/style.css?v=<?php echo time()?>" rel="stylesheet" />
</head>

<body>
    <?php // Only if you're embedding inside iframe (optional)
header("X-Frame-Options: ALLOW-FROM https://*.bitrix24.com");
?>
    <div class="topbar">
        <div class="left">Team / <span>My Team</span> </div>

        <div class="user-select-container">
            <!-- <div class="input-wrapper">
                <input type="text" id="userInput" placeholder="Select User" oninput="filterUsers()" onfocus="showDropdown()" />
                <img class="dropdown-arrow" src="https://cdn-icons-png.flaticon.com/512/2985/2985150.png" alt="dropdown arrow">
            </div> -->
            
            <select class="form-control user_filter"  name="user_id[]" id="user_id" size="6">

                </select>
            <!-- <div class="search-icon">
                <img src="https://cdn-icons-png.flaticon.com/512/54/54481.png" alt="search">
            </div> -->
            
        </div>
        <div class="project-status-container">
            <select class="form-control" name="project_status" id="project_status" multiple>
              <option value="branch" data-image="https://anuda.net/location/timeline/img/anuda.png">Branches</option>
              <option value="upcomming" data-image="https://anuda.net/location/timeline/img/comming_soon.png">Upcoming Project</option>
              <option value="inprogress" data-image="https://anuda.net/location/timeline/img/live_projects.png">Live Project</option>
              <option value="completed" data-image="https://anuda.net/location/timeline/img/won.png">Completed Projects</option>
            </select>
        </div>

    </div>

    <div id="map"></div>

    <div class="travel-box">
        <div class="btns">
            <button class="active" onclick="setView(this)">Map</button>
            <button onclick="setView(this)">Satellite</button>
        </div>
        <div class="btns">
            <button onclick="setView(this)">Travel View</button>
            <button onclick="setView(this)">Location View</button>
        </div>
        <div class="refresh">
            <a href="#"><i class="fa-solid fa-arrow-rotate-right"></i></a>
        </div>
    </div>

    <div class="sidebar">
        <!-- <div id="dismiss" onclick="backToPreviousPage();" class="hideTimeLineClass"><i class="glyphicon glyphicon-arrow-right" id="change_arrow"></i></div> -->
        <div class="header">
            <div class="main_part">
                <div class="avatar">
                    <i class="fa-solid fa-user"></i>
                    <!-- <img alt="" src="img/usrsml_29.png" onerror="this.src='img/usrsml_29.png';"> -->
                </div>
                <div class="id_set">
                    <h2></h2>
                </div>
            </div>
            <div class="smart_p">
                <img src="img/smartphone.png" alt="user">
            </div>
        </div>
        <div class="stats">
            <div class="data_set"><strong>0%</strong><br>FTR</div>
            <div class="data_set2"><i class="fa-solid fa-briefcase"></i>
                <br>
                <div id="totalVisits"></div></div>
            <div class="data_set2"><i class="fa-solid fa-route"></i>  <br> <div id="totalDistance"></div></div>
            <div class="data_set2"><i class="fa-solid fa-building"></i> <br> <strong>Office</strong><br>0 min</div>
        </div>
        <div class="timeline">
            <div class="title">
                <!-- <span>TIMELINE</span> -->
                <span id="selectedDate"><?php echo date('d F Y')?></span>
                <div class="calendar-wrapper">
                    <?php if(isset($_GET['user_id']) && $_GET['user_id'] !=''){?>
                    <i class="fa-regular fa-calendar calendar-icon" onclick="toggleCalendar()"></i>
                    <?php } else{ ?>
                    <i class="fa-regular fa-calendar calendar-icon"></i>
                    <?php } ?>
                    <div class="calendar-input" id="calendarInput">
                        <input type="date" id="datePicker" onchange="updateDate()">
                    </div> 
                </div>
            </div>
            <div class="timeline-wrapper">
            <div class="timeline-detail">
                <div class="tabs2">
            <span>PENDING VISITS</span>
        </div>
            </div>
            </div>
        </div>
        
    </div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<!-- Leaflet CDN (no API key needed) -->
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script src="/location/timeline/js/custom.js?v=<?php echo time()?>"></script>



</body>

</html>